-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 11 Feb 2025 pada 07.13
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rumah_sakit`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `dokter`
--

CREATE TABLE `dokter` (
  `id_dokter` int(11) NOT NULL,
  `nama_dokter` varchar(100) NOT NULL,
  `nik` varchar(50) DEFAULT NULL,
  `spesialis` varchar(100) NOT NULL,
  `telepon` varchar(15) NOT NULL,
  `alamat` text DEFAULT NULL,
  `foto` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `dokter`
--

INSERT INTO `dokter` (`id_dokter`, `nama_dokter`, `nik`, `spesialis`, `telepon`, `alamat`, `foto`) VALUES
(6, 'dr. Veren', '497676484846', 'Mata', '085608452028', 'Pasuruan ', '9b45930dd2267630666989373553c55c.jpg'),
(7, 'dr. Akil', '946764846137', 'Bedah Ortopedi', '081626198293', 'kandangan ', '67a82442cc34c.jpg'),
(8, 'dr. Surya', '497676484938', 'Bedah Jantung', '085608452028', 'Pare', '67a8555fa337b.jpg'),
(10, 'dr. Teresia', '497676484846', 'Kulit', '082345124129', 'Kediri', '67a87bdee5a19.jpg'),
(11, 'dr. Lala', '497676484938', 'Bedah Saraf', '085608452028', 'Jakarta', '67a87ea6c499d.jpg'),
(12, 'dr. Michele', '646438548489', 'Penyakit Dalam', '085315456968', 'Bekasi', '67a89c8e4bbe7.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kamar`
--

CREATE TABLE `kamar` (
  `id_kamar` int(11) NOT NULL,
  `nomor_kamar` varchar(10) NOT NULL,
  `tipe_kamar` varchar(50) NOT NULL,
  `kapasitas` int(11) NOT NULL,
  `tersedia` enum('Ya','Tidak') NOT NULL DEFAULT 'Ya',
  `harga_per_malam` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `kamar`
--

INSERT INTO `kamar` (`id_kamar`, `nomor_kamar`, `tipe_kamar`, `kapasitas`, `tersedia`, `harga_per_malam`) VALUES
(1, '101', 'VIP', 2, 'Ya', 750000.00),
(2, '102', 'VIP', 2, 'Tidak', 750000.00),
(3, '103', 'VIP', 2, 'Ya', 750000.00),
(4, '104', 'VIP', 2, 'Ya', 750000.00),
(5, '105', 'Kelas 1', 4, 'Ya', 500000.00),
(6, '106', 'Kelas 1', 4, 'Tidak', 500000.00),
(7, '107', 'Kelas 1', 4, 'Ya', 500000.00),
(8, '108', 'Kelas 1', 4, 'Ya', 500000.00),
(9, '109', 'Kelas 2', 6, 'Ya', 350000.00),
(10, '110', 'Kelas 2', 6, 'Ya', 350000.00),
(11, '111', 'Kelas 2', 6, 'Tidak', 350000.00),
(12, '112', 'Kelas 2', 6, 'Ya', 350000.00),
(13, '113', 'Kelas 3', 8, 'Ya', 200000.00),
(14, '114', 'Kelas 3', 8, 'Ya', 200000.00),
(15, '115', 'Kelas 3', 8, 'Tidak', 200000.00),
(16, '116', 'Kelas 3', 8, 'Ya', 200000.00),
(17, '117', 'ICU', 1, 'Ya', 1000000.00),
(18, '118', 'ICU', 1, 'Tidak', 1000000.00),
(19, '119', 'ICU', 1, 'Ya', 1000000.00),
(20, '120', 'ICU', 1, 'Ya', 1000000.00),
(23, '121', 'umum', 35, 'Tidak', 1000000.00),
(25, '121', 'umum', 2, 'Ya', 2000000.00);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pasien`
--

CREATE TABLE `pasien` (
  `id_pasien` int(11) NOT NULL,
  `nik` varchar(40) DEFAULT NULL,
  `nama_pasien` varchar(255) NOT NULL,
  `jenis_kelamin` enum('L','P') NOT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `telepon` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `pasien`
--

INSERT INTO `pasien` (`id_pasien`, `nik`, `nama_pasien`, `jenis_kelamin`, `alamat`, `telepon`) VALUES
(24, '64643854848136', 'Mila', 'P', 'Kediri', '0823451241212'),
(27, '02458350430356', 'Ciki', 'P', 'kaliurang', '0897252436298'),
(28, '24835053003569', 'Jaya', 'L', 'kaliurang', '0856084520287'),
(37, '49767648493836', 'Jessica', 'P', 'Madiun', '0816261982930'),
(39, '15646546846544', 'Raya ', 'P', 'Jogja', '0865214922549'),
(40, '59631458723694', 'Rani', 'P', 'Jakarta', '0863125496521'),
(41, '23651469875236', 'Riko', 'L', 'Sulawesi', '0853164792364'),
(42, '21669742365412', 'Budi', 'L', 'Malang', '0854123697542');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pasien_rawat_inap`
--

CREATE TABLE `pasien_rawat_inap` (
  `id_pasien` int(11) NOT NULL,
  `nik` varchar(16) NOT NULL,
  `nama_pasien` varchar(100) NOT NULL,
  `jenis_kelamin` enum('L','P') NOT NULL,
  `alamat` text NOT NULL,
  `telepon` varchar(15) NOT NULL,
  `tanggal_daftar` date DEFAULT NULL,
  `tanggal_keluar` date DEFAULT NULL,
  `dokter` varchar(100) NOT NULL,
  `id_kamar` int(11) NOT NULL,
  `pembayaran` decimal(10,2) NOT NULL,
  `status_pembayaran` enum('Lunas','Belum Lunas') NOT NULL,
  `keluhan` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `pasien_rawat_inap`
--

INSERT INTO `pasien_rawat_inap` (`id_pasien`, `nik`, `nama_pasien`, `jenis_kelamin`, `alamat`, `telepon`, `tanggal_daftar`, `tanggal_keluar`, `dokter`, `id_kamar`, `pembayaran`, `status_pembayaran`, `keluhan`) VALUES
(27, '02458350430356', 'Ciki', 'P', 'kaliurang', '0897252436298', '2025-02-11', '2025-02-15', 'dr. Teresia', 6, 5000000.00, 'Lunas', 'Infeksi jamur'),
(37, '49767648493836', 'Jessica', 'P', 'Madiun', '0816261982930', '2025-02-11', '2025-02-14', 'dr. Akil', 14, 50000000.00, 'Lunas', 'Patah tulang lengan'),
(40, '59631458723694', 'Rani', 'P', 'Jakarta', '0863125496521', '2025-02-12', '2025-02-15', 'dr. Veren', 11, 12000000.00, 'Belum Lunas', 'Lasik mata'),
(42, '21669742365412', 'Budi', 'L', 'Malang', '0854123697542', '2025-02-11', '2025-02-21', 'dr. Surya', 5, 99999999.99, 'Belum Lunas', 'Jantung bocor');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pasien_rawat_jalan`
--

CREATE TABLE `pasien_rawat_jalan` (
  `id_pasien` int(11) NOT NULL,
  `nik` varchar(20) NOT NULL,
  `nama_pasien` varchar(100) NOT NULL,
  `jenis_kelamin` enum('L','P') NOT NULL,
  `alamat` text NOT NULL,
  `telepon` varchar(15) NOT NULL,
  `id_dokter` int(11) DEFAULT NULL,
  `tanggal_kunjungan` date NOT NULL,
  `keluhan` text DEFAULT NULL,
  `pembayaran` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `pasien_rawat_jalan`
--

INSERT INTO `pasien_rawat_jalan` (`id_pasien`, `nik`, `nama_pasien`, `jenis_kelamin`, `alamat`, `telepon`, `id_dokter`, `tanggal_kunjungan`, `keluhan`, `pembayaran`) VALUES
(4, '', 'Roni', 'L', 'Malang', '0816261982930', 6, '2025-02-09', 'Muntaber', 0.00),
(5, '', 'Andrea', 'P', 'Jambi', '0856084520283', 7, '2025-02-09', 'Hipertensi', 0.00),
(6, '', 'Yanto', 'L', 'Madiun', '0816261982930', 7, '2025-02-10', 'Diare', 0.00),
(7, '', 'Desi', 'P', 'Jogja', '0856649764641', 6, '2025-02-11', 'Anemia', 0.00);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tenaga_kerja`
--

CREATE TABLE `tenaga_kerja` (
  `id_tenaga_kerja` int(11) NOT NULL,
  `nik` varchar(16) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `jenis_kelamin` enum('L','P') NOT NULL,
  `jabatan` varchar(50) NOT NULL,
  `alamat` text NOT NULL,
  `telepon` varchar(15) NOT NULL,
  `foto` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `tenaga_kerja`
--

INSERT INTO `tenaga_kerja` (`id_tenaga_kerja`, `nik`, `nama`, `jenis_kelamin`, `jabatan`, `alamat`, `telepon`, `foto`) VALUES
(2, '', 'verenwdsdfw', 'P', 'fewqfqew', 'swwfeqaf', '08234512412', 'pasien.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(2, 'admin', '21232f297a57a5a743894a0e4a801fc3'),
(3, 'administrator', '$2y$10$bWiRR21koYnjrdw9YMulBOPoOITt2hdWPDMFQT1Gdvexj2xucibLG'),
(4, 'kelompok', '$2y$10$WUw0jUAaMjrQVmI/n3mWO.IE.2GaOZ33VhXtpsxxRiVwcVraJwafK');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `dokter`
--
ALTER TABLE `dokter`
  ADD PRIMARY KEY (`id_dokter`);

--
-- Indeks untuk tabel `kamar`
--
ALTER TABLE `kamar`
  ADD PRIMARY KEY (`id_kamar`);

--
-- Indeks untuk tabel `pasien`
--
ALTER TABLE `pasien`
  ADD PRIMARY KEY (`id_pasien`);

--
-- Indeks untuk tabel `pasien_rawat_inap`
--
ALTER TABLE `pasien_rawat_inap`
  ADD PRIMARY KEY (`id_pasien`),
  ADD KEY `id_kamar` (`id_kamar`);

--
-- Indeks untuk tabel `pasien_rawat_jalan`
--
ALTER TABLE `pasien_rawat_jalan`
  ADD PRIMARY KEY (`id_pasien`),
  ADD KEY `id_dokter` (`id_dokter`);

--
-- Indeks untuk tabel `tenaga_kerja`
--
ALTER TABLE `tenaga_kerja`
  ADD PRIMARY KEY (`id_tenaga_kerja`),
  ADD UNIQUE KEY `nik` (`nik`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `dokter`
--
ALTER TABLE `dokter`
  MODIFY `id_dokter` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT untuk tabel `kamar`
--
ALTER TABLE `kamar`
  MODIFY `id_kamar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT untuk tabel `pasien`
--
ALTER TABLE `pasien`
  MODIFY `id_pasien` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT untuk tabel `pasien_rawat_inap`
--
ALTER TABLE `pasien_rawat_inap`
  MODIFY `id_pasien` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT untuk tabel `pasien_rawat_jalan`
--
ALTER TABLE `pasien_rawat_jalan`
  MODIFY `id_pasien` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `tenaga_kerja`
--
ALTER TABLE `tenaga_kerja`
  MODIFY `id_tenaga_kerja` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `pasien_rawat_inap`
--
ALTER TABLE `pasien_rawat_inap`
  ADD CONSTRAINT `pasien_rawat_inap_ibfk_1` FOREIGN KEY (`id_kamar`) REFERENCES `kamar` (`id_kamar`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `pasien_rawat_jalan`
--
ALTER TABLE `pasien_rawat_jalan`
  ADD CONSTRAINT `pasien_rawat_jalan_ibfk_1` FOREIGN KEY (`id_dokter`) REFERENCES `dokter` (`id_dokter`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
