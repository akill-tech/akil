<?php
include '../koneksi.php';

$id_pasien = $_POST['id_pasien'];
$nik = $_POST['nik'];
$nama_pasien = $_POST['nama_pasien'];
$jenis_kelamin = $_POST['jenis_kelamin'];
$alamat = $_POST['alamat'];
$telepon = $_POST['telepon'];
$type_rawat = $_POST['type_rawat'];

$query = "UPDATE pasien SET 
    nik = '$nik', 
    nama_pasien = '$nama_pasien', 
    jenis_kelamin = '$jenis_kelamin', 
    alamat = '$alamat', 
    telepon = '$telepon', 
    type_rawat = '$type_rawat'
    WHERE id_pasien = '$id_pasien'";

if ($koneksi->query($query) === TRUE) {
    header("Location: tampil_pasien.php");
} else {
    echo "Error: " . $query . "<br>" . $koneksi->error;
}
?>
