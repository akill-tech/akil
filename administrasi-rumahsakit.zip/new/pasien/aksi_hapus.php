<?php
include '../koneksi.php';

// Periksa apakah parameter id_pasien dikirim melalui GET
if (!empty($_GET['id_pasien'])) {
    $id_pasien = mysqli_real_escape_string($koneksi, $_GET['id_pasien']);

    // Periksa apakah ID pasien benar-benar ada di database
    $cek = $koneksi->query("SELECT id_pasien FROM pasien WHERE id_pasien = '$id_pasien'");
    
    if ($cek->num_rows > 0) {
        // Jika ID ditemukan, jalankan query hapus
        $query = "DELETE FROM pasien WHERE id_pasien = '$id_pasien'";

        if ($koneksi->query($query) === TRUE) {
            echo "<script>
                    alert('Data pasien berhasil dihapus!');
                    window.location.href = 'tampil_pasien.php';
                  </script>";
        } else {
            echo "<script>
                    alert('Gagal menghapus data pasien: " . addslashes($koneksi->error) . "');
                    window.history.back();
                  </script>";
        }
    } else {
        // Jika ID tidak ditemukan di database
        echo "<script>
                alert('Data pasien tidak ditemukan!');
                window.location.href = 'tampil_pasien.php';
              </script>";
    }
} else {
    // Jika tidak ada id_pasien di URL
    echo "<script>
            alert('ID Pasien tidak valid!');
            window.location.href = 'tampil_pasien.php';
          </script>";
}

// Tutup koneksi database
$koneksi->close();
?>
