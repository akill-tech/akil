<?php
session_start();
include '../koneksi.php';

// Ambil data pasien
$query = "SELECT * FROM pasien";
$result = $koneksi->query($query);
$cari = isset($_GET['cari']) ? $_GET['cari'] : '';
$query = "SELECT * FROM pasien";

if ($cari) {
    $query .= " WHERE nama_pasien LIKE '%$cari%' OR nik LIKE '%$cari%' OR alamat LIKE '%$cari%' OR telepon LIKE '%$cari%'";
}

$result = $koneksi->query($query);

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Pasien</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body class="bg-gray-100">

<header class="bg-white shadow">
    <div class="container mx-auto px-4 py-4 flex justify-between items-center">
        <div class="flex items-center space-x-4">
            <span class="text-lg font-semibold">Sistem Informasi Rumah Sakit</span>
            <nav class="flex space-x-4">
               <a href="../index.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                <i class="fas fa-home"></i>
                    Dasboard
                </a>
                <a href="tampil_pasien.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                    <i class="fas fa-user"></i>Data Pasien
                </a>
                <a href="../prj/tampil_prj.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                    <i class="fas fa-bed"></i> Pasien Rawat Jalan
                </a>
                <a href="../pri/tampil_pri.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                    <i class="fas fa-procedures"></i> Pasien Rawat Inap
                </a>
                <a href="../kamar/tampil_kamar.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                    <i class="fas fa-hospital"></i> Daftar Kamar
                </a>
                <a href="../dokter/tampil_dokter.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                    <i class="fas fa-user-md"></i> Daftar Dokter
                </a>
                 <a href="../tkerja/tampil_tenaga_kerja.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                    <i class="fas fa-user-md"></i> Daftar Tenaga Kerja
                </a>
            </nav>
        </div>
        <div class="flex items-center space-x-4">
            <span class="text-gray-700">Selamat Datang, <strong><?= $_SESSION['username']; ?></strong></span>
            <a href="../logout.php" class="text-red-600">Logout</a>
        </div>
    </div>
</header>

<main class="container mx-auto px-4 py-8">
    <div class="bg-white shadow rounded-lg p-6">
        <div class="text-center mb-6">
            <h1 class="text-2xl font-semibold text-green-600">Data Pasien</h1>
            <button onclick="openModalTambah()" class="mt-4 px-4 py-2 bg-green-600 text-white rounded">
                + Tambah Pasien
            </button>
        </div>
        <form method="GET" action="tampil_pasien.php" class="flex items-center space-x-2">
        <input type="text" name="cari" value="<?= htmlspecialchars($cari); ?>" placeholder="Cari nama pasien..." class="px-4 py-2 border rounded-lg w-1/3">
        <button type="submit" class="px-4 py-2 bg-green-600 text-white rounded">Cari</button>
        <a href="tampil_pasien.php" class="px-4 py-2 bg-gray-600 text-white rounded">Reset</a>
    </form>


        <div class="overflow-x-auto mt-6">
            <table class="min-w-full bg-white border">
                <thead>
                    <tr class="bg-gray-200 text-gray-600 uppercase text-sm leading-normal">
                        <th class="py-3 px-6 text-left">No</th>
                        <th class="py-3 px-6 text-left">ID Pasien</th>
                        <th class="py-3 px-6 text-left">NIK</th>
                        <th class="py-3 px-6 text-left">Nama Pasien</th>
                        <th class="py-3 px-6 text-left">Jenis Kelamin</th>
                        <th class="py-3 px-6 text-left">Alamat</th>
                        <th class="py-3 px-6 text-left">Telepon</th>
                        <th class="py-3 px-6 text-left">Tipe Rawat</th>
                        <th class="py-3 px-6 text-left">Aksi</th>
                    </tr>
                </thead>
<tbody class="text-gray-600 text-sm font-light">
    <?php $no = 1; while ($row = $result->fetch_assoc()) { ?>
        <tr class='border-b border-gray-200 hover:bg-gray-100'>
            <td class='py-3 px-6 text-left font-bold'><?= $no++; ?></td>
            <td class='py-3 px-6 text-left font-bold'><?= $row['id_pasien']; ?></td>
            <td class='py-3 px-6 text-left font-bold'><?= $row['nik']; ?></td>
            <td class='py-3 px-6 text-left font-bold'><?= $row['nama_pasien']; ?></td>
            <td class='py-3 px-6 text-left font-bold'><?= ($row['jenis_kelamin'] == "L") ? "Laki-laki" : "Perempuan"; ?></td>
            <td class='py-3 px-6 text-left font-bold'><?= $row['alamat']; ?></td>
            <td class='py-3 px-6 text-left font-bold'><?= $row['telepon']; ?></td>
            <td class='py-3 px-6 text-left font-bold'><?= $row['type_rawat']; ?></td>
            <td class='py-3 px-6 text-left font-bold'>
                <button onclick="openModalEdit(<?= htmlspecialchars(json_encode($row)) ?>)" class='text-blue-600'><i class='fas fa-edit'></i></button>
                <a href="aksi_hapus.php?id_pasien=<?= $row['id_pasien']; ?>" class='text-red-600' onclick="return confirm('Yakin ingin menghapus?')">
                    <i class='fas fa-trash'></i>
                </a>
            </td>
        </tr>
    <?php } ?>
</tbody>

            </table>
        </div>
    </div>
</main>
<!-- MODAL TAMBAH PASIEN -->
<div id="modalTambah" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden">
    <div class="bg-white p-6 rounded-lg shadow-lg w-1/3">
        <h2 class="text-lg font-semibold mb-4 text-center text-green-600">Tambah Pasien</h2>
        <form action="aksi_tambah_pasien.php" method="POST">
          <label class="block text-gray-700">NIK</label>
            <input type="text" name="nik" required class="w-full p-2 border rounded mb-2">
            <label class="block text-gray-700">Nama Pasien</label>
            <input type="text" name="nama_pasien" required class="w-full p-2 border rounded mb-2">

            <label class="block text-gray-700">Jenis Kelamin</label>
            <select name="jenis_kelamin" required class="w-full p-2 border rounded mb-2">
                <option value="L">Laki-laki</option>
                <option value="P">Perempuan</option>
            </select>

            <label class="block text-gray-700">Alamat</label>
            <input type="text" name="alamat" required class="w-full p-2 border rounded mb-2">

            <label class="block text-gray-700">Telepon</label>
            <input type="text" name="telepon" required class="w-full p-2 border rounded mb-2">
            <label class="block text-gray-700">Type Rawat</label>
<select name="type_rawat" id="type_rawat" class="w-full p-2 border rounded mb-2">
    <option value="">Pilih Type Rawat</option>
    <option value="Jalan">Rawat Jalan</option>
    <option value="Inap">Rawat Inap</option>
</select>


            <div class="flex justify-end space-x-2 mt-4">
                <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded">Simpan</button>
                <button type="button" onclick="closeModalTambah()" class="px-4 py-2 bg-gray-400 text-white rounded">Batal</button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL EDIT PASIEN -->
<div id="modalEdit" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden">
    <div class="bg-white p-6 rounded-lg shadow-lg w-1/3">
        <h2 class="text-lg font-semibold mb-4 text-center text-green-600">Edit Pasien</h2>
        <form action="aksi_edit_pasien.php" method="POST">
            <input type="hidden" id="edit_id_pasien" name="id_pasien">
                        <label class="block text-gray-700">NIK</label>
            <input type="text" id="edit_nik" name="nik" class="w-full p-2 border rounded mb-2">

            <label class="block text-gray-700">Nama Pasien</label>
            <input type="text" id="edit_nama_pasien" name="nama_pasien" required class="w-full p-2 border rounded mb-2">

            <label class="block text-gray-700">Jenis Kelamin</label>
            <select id="edit_jenis_kelamin" name="jenis_kelamin" required class="w-full p-2 border rounded mb-2">
                <option value="L">Laki-laki</option>
                <option value="P">Perempuan</option>
            </select>
            <label class="block text-gray-700">Type Rawat</label>
<select id="edit_type_rawat" name="type_rawat" class="w-full p-2 border rounded mb-2">
    <option value="">Pilih Type Rawat</option>
    <option value="Jalan">Rawat Jalan</option>
    <option value="Inap">Rawat Inap</option>
</select>




            <label class="block text-gray-700">Alamat</label>
            <input type="text" id="edit_alamat" name="alamat" required class="w-full p-2 border rounded mb-2">

            <label class="block text-gray-700">Telepon</label>
            <input type="text" id="edit_telepon" name="telepon" required class="w-full p-2 border rounded mb-2">

            <div class="flex justify-end space-x-2 mt-4">
                <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded">Simpan</button>
                <button type="button" onclick="closeModalEdit()" class="px-4 py-2 bg-gray-400 text-white rounded">Batal</button>
            </div>
        </form>
    </div>
</div>

<script>
    document.querySelector("form[action='aksi_tambah_pasien.php']").addEventListener("submit", function(event) {
    var typeRawat = document.getElementById("type_rawat").value;
    if (typeRawat === "") {
        // Biarkan kosong, tidak ada pilihan yang dipilih
        document.getElementById("type_rawat").value = "";
    }
});

    function openModalTambah() {
        document.getElementById("modalTambah").classList.remove("hidden");
    }
    function closeModalTambah() {
        document.getElementById("modalTambah").classList.add("hidden");
    }
    function openModalEdit(pasien) {
        document.getElementById("edit_id_pasien").value = pasien.id_pasien;
                document.getElementById("edit_nik").value = pasien.nik; // Tambahkan NIK
        document.getElementById("edit_nama_pasien").value = pasien.nama_pasien;
        document.getElementById("edit_jenis_kelamin").value = pasien.jenis_kelamin;
        document.getElementById("edit_alamat").value = pasien.alamat;
        document.getElementById("edit_telepon").value = pasien.telepon;
        document.getElementById("edit_type_rawat").value = pasien.type_rawat;
        document.getElementById("modalEdit").classList.remove("hidden");
    }
    function closeModalEdit() {
        document.getElementById("modalEdit").classList.add("hidden");
    }
    // Logika untuk Type Rawat
    var typeRawat = pasien.type_rawat;
    if (typeRawat === null || typeRawat === "") {
        document.getElementById("edit_type_rawat").selectedIndex = 0; // Pilih opsi pertama (kosong)
    } else {
        document.getElementById("edit_type_rawat").value = typeRawat;
    }

    document.getElementById("modalEdit").classList.remove("hidden");
</script>

</body>
</html>