<?php
include '../koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form dan sanitasi input
    $nik           = mysqli_real_escape_string($koneksi, $_POST['nik']);
    $nama_pasien   = mysqli_real_escape_string($koneksi, $_POST['nama_pasien']);
    $jenis_kelamin = isset($_POST['jenis_kelamin']) ? $_POST['jenis_kelamin'] : '';
    $alamat        = mysqli_real_escape_string($koneksi, $_POST['alamat']);
    $telepon       = mysqli_real_escape_string($koneksi, $_POST['telepon']);
    $type_rawat    = isset($_POST['type_rawat']) ? $_POST['type_rawat'] : '';

    // Validasi NIK harus angka (tanpa batasan jumlah digit)
    if (!empty($nik) && !preg_match('/^[0-9]+$/', $nik)) {
        echo "<script>
                alert('NIK harus berupa angka!');
                window.history.back();
              </script>";
        exit;
    }

    // Cek apakah NIK sudah ada di database (jika diisi)
    if (!empty($nik)) {
        $cek_nik = "SELECT * FROM pasien WHERE nik = '$nik'";
        $result_nik = $koneksi->query($cek_nik);

        if ($result_nik->num_rows > 0) {
            echo "<script>
                    alert('NIK sudah terdaftar! Silakan gunakan NIK lain.');
                    window.history.back();
                  </script>";
            exit;
        }
    }

    // Validasi Jenis Kelamin
    if ($jenis_kelamin !== "L" && $jenis_kelamin !== "P") {
        echo "<script>
                alert('Jenis kelamin tidak valid!');
                window.history.back();
              </script>";
        exit;
    }

    // Validasi Type Rawat
    if ($type_rawat !== "Jalan" && $type_rawat !== "Inap" && $type_rawat !== "") {
        echo "<script>
                alert('Tipe Rawat tidak valid!');
                window.history.back();
              </script>";
        exit;
    }

    // Query INSERT dengan Type Rawat opsional (boleh kosong)
    $query = "INSERT INTO pasien (nik, nama_pasien, jenis_kelamin, alamat, telepon, type_rawat) 
              VALUES (?, ?, ?, ?, ?, ?)";

    $stmt = $koneksi->prepare($query);
    $stmt->bind_param("ssssss", $nik, $nama_pasien, $jenis_kelamin, $alamat, $telepon, $type_rawat);

    if ($stmt->execute()) {
        echo "<script>
                alert('Data pasien berhasil ditambahkan!');
                window.location.href = 'tampil_pasien.php';
              </script>";
    } else {
        echo "<script>
                alert('Gagal menambahkan data pasien: " . addslashes($stmt->error) . "');
                window.history.back();
              </script>";
    }

    $stmt->close();
}

$koneksi->close();
?>
