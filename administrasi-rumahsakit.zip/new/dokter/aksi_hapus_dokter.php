<?php
include '../koneksi.php';

if (isset($_GET['id_dokter'])) {
    $id_dokter = $_GET['id_dokter'];

    // Ambil nama file foto dokter sebelum menghapus data
    $query = "SELECT foto FROM dokter WHERE id_dokter = ?";
    $stmt = $koneksi->prepare($query);
    $stmt->bind_param("i", $id_dokter);
    $stmt->execute();
    $stmt->bind_result($foto);
    $stmt->fetch();
    $stmt->close();

    // Hapus data dokter dari database
    $query_delete = "DELETE FROM dokter WHERE id_dokter = ?";
    $stmt_delete = $koneksi->prepare($query_delete);
    $stmt_delete->bind_param("i", $id_dokter);

    if ($stmt_delete->execute()) {
        // Hapus foto dari folder jika ada
        $file_path = "uploads/" . $foto;
        if ($foto && file_exists($file_path)) {
            unlink($file_path);
        }

        // Redirect kembali ke tampil_dokter.php
        header("Location: tampil_dokter.php");
        exit();
    } else {
        echo "Error: Gagal menghapus dokter.";
    }
} else {
    echo "Error: ID dokter tidak ditemukan.";
}
?>
