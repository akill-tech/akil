<?php
include '../koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nik = $_POST['nik'];
    $nama_dokter = $_POST['nama_dokter'];
    $spesialis = $_POST['spesialis'];
    $telepon = $_POST['telepon'];
    $alamat = $_POST['alamat'];

    // Proses Upload Foto
    $target_dir = "uploads/";
    $foto_name = basename($_FILES["foto"]["name"]);
    $imageFileType = strtolower(pathinfo($foto_name, PATHINFO_EXTENSION));
    $new_foto_name = uniqid() . "." . $imageFileType; // Rename file agar unik
    $target_file = $target_dir . $new_foto_name;
    $uploadOk = 1;

    // Pastikan folder uploads ada
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    // Cek apakah file adalah gambar
    $check = getimagesize($_FILES["foto"]["tmp_name"]);
    if ($check === false) {
        die("Error: File bukan gambar.");
    }

    // Batasi jenis file yang diperbolehkan
    $allowed_types = ["jpg", "jpeg", "png", "gif"];
    if (!in_array($imageFileType, $allowed_types)) {
        die("Error: Hanya file JPG, JPEG, PNG, dan GIF yang diperbolehkan.");
    }

    // Batasi ukuran file maksimal 2MB
    if ($_FILES["foto"]["size"] > 2000000) {
        die("Error: Ukuran file terlalu besar. Maksimal 2MB.");
    }

    // Upload file ke server
    if (move_uploaded_file($_FILES["foto"]["tmp_name"], $target_file)) {
        // Simpan data dokter ke database
        $query = "INSERT INTO dokter (nik, nama_dokter, spesialis, telepon, alamat, foto) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $koneksi->prepare($query);
        $stmt->bind_param("ssssss", $nik, $nama_dokter, $spesialis, $telepon, $alamat, $new_foto_name);

        if ($stmt->execute()) {
            // Redirect ke tampil_dokter.php setelah berhasil
            header("Location: tampil_dokter.php");
            exit();
        } else {
            die("Error: Gagal menyimpan ke database.");
        }
    } else {
        die("Error: Gagal mengunggah foto.");
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Dokter</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <div class="container mx-auto px-4 py-8">
        <div class="bg-white shadow rounded-lg p-6">
            <h2 class="text-2xl font-semibold text-blue-600 mb-4">Tambah Dokter</h2>
            <form action="upload_dokter.php" method="POST" enctype="multipart/form-data">
                <div class="mb-4">
                    <label class="block text-gray-700">NIK</label>
                    <input type="text" name="nik" class="w-full px-4 py-2 border rounded" required>
                </div>
                <div class="mb-4">
                    <label class="block text-gray-700">Nama Dokter</label>
                    <input type="text" name="nama_dokter" class="w-full px-4 py-2 border rounded" required>
                </div>
                <div class="mb-4">
                    <label class="block text-gray-700">Spesialis</label>
                    <input type="text" name="spesialis" class="w-full px-4 py-2 border rounded" required>
                </div>
                <div class="mb-4">
                    <label class="block text-gray-700">Telepon</label>
                    <input type="text" name="telepon" class="w-full px-4 py-2 border rounded" required>
                </div>
                <div class="mb-4">
                    <label class="block text-gray-700">Alamat</label>
                    <textarea name="alamat" class="w-full px-4 py-2 border rounded" required></textarea>
                </div>
                <div class="mb-4">
                    <label class="block text-gray-700">Foto Dokter</label>
                    <input type="file" name="foto" class="w-full px-4 py-2 border rounded" required>
                </div>
                <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded">Tambah Dokter</button>
            </form>
        </div>
    </div>
</body>
</html>
