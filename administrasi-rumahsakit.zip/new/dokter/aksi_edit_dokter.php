<?php
session_start();
include '../koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_dokter'])) {
    $id_dokter = $_POST['edit_id_dokter'];
    $nama_dokter = $_POST['edit_nama_dokter'];
    $nik = $_POST['edit_nik'];
    $spesialis = $_POST['edit_spesialis'];
    $telepon = $_POST['edit_telepon'];
    $alamat = $_POST['edit_alamat'];

    // Cek apakah ada file yang diupload
    if (!empty($_FILES['edit_foto']['name'])) {
        $foto_name = $_FILES['edit_foto']['name'];
        $foto_tmp = $_FILES['edit_foto']['tmp_name'];
        $foto_folder = "uploads/" . $foto_name;

        // Pindahkan file ke folder uploads
        if (move_uploaded_file($foto_tmp, $foto_folder)) {
            // Update database dengan foto baru
            $query = "UPDATE dokter SET nama_dokter='$nama_dokter', nik='$nik', spesialis='$spesialis', telepon='$telepon', alamat='$alamat', foto='$foto_name' WHERE id_dokter='$id_dokter'";
        } else {
            echo "<script>alert('Gagal mengupload foto!'); window.location='tampil_dokter.php';</script>";
            exit;
        }
    } else {
        // Jika tidak ada foto baru, update tanpa mengubah foto lama
        $query = "UPDATE dokter SET nama_dokter='$nama_dokter', nik='$nik', spesialis='$spesialis', telepon='$telepon', alamat='$alamat' WHERE id_dokter='$id_dokter'";
    }

    if ($koneksi->query($query)) {
        echo "<script>alert('Data dokter berhasil diperbarui!'); window.location='tampil_dokter.php';</script>";
    } else {
        echo "<script>alert('Gagal memperbarui data!');</script>";
    }
}
?>
