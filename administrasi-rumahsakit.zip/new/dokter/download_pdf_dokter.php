<?php
require_once('../tcpdf/tcpdf.php');
require_once('../koneksi.php'); // Koneksi database

// Periksa apakah ID dokter dikirim
if (isset($_GET['id_dokter'])) {
    $id_dokter = $_GET['id_dokter'];

    // Ambil data dokter dari database
    $query = "SELECT * FROM dokter WHERE id_dokter = ?";
    $stmt = $koneksi->prepare($query);
    $stmt->bind_param("s", $id_dokter);
    $stmt->execute();
    $result = $stmt->get_result();
    $dokter = $result->fetch_assoc();

    if (!$dokter) {
        die("Data dokter tidak ditemukan.");
    }

    // Kelas custom TCPDF untuk header & footer
    class MYPDF extends TCPDF {
        public function Header() {
            // Logo Rumah Sakit
            $image_file = '../images/logo.png'; // Path logo rumah sakit
            if (file_exists($image_file)) {
                $this->Image($image_file, 15, 10, 20); // Logo kecil di kiri atas
            }

            // Judul Rumah Sakit
            $this->SetFont('helvetica', 'B', 16);
            $this->Cell(0, 5, 'RUMAH SAKIT MEDIKA PRATAMA', 0, 1, 'C');

            // Informasi Rumah Sakit
            $this->SetFont('helvetica', '', 10);
            $this->Cell(0, 5, 'Jl. Kesehatan No. 123, Jakarta', 0, 1, 'C');
            $this->Cell(0, 5, 'Telp: (021) 555-6789 | Email: info@rssehat.com', 0, 1, 'C');

            // Judul Laporan
            $this->SetFont('helvetica', 'B', 12);
            $this->Cell(0, 8, 'LAPORAN DATA DOKTER', 0, 1, 'C');

            // Garis pemisah setelah header
            $this->Ln(2);
            $this->Cell(190, 0, '', 'T', 1, 'C');
            $this->Ln(5);
        }

        public function Footer() {
            $this->SetY(-15);
            $this->SetFont('helvetica', 'I', 8);
            $this->Cell(0, 10, 'Halaman ' . $this->getAliasNumPage() . ' dari ' . $this->getAliasNbPages(), 0, 0, 'C');
        }
    }

    // Inisialisasi PDF
    $pdf = new MYPDF('P', 'mm', 'A4', true, 'UTF-8', false);
    $pdf->SetMargins(15, 40, 15);
    $pdf->SetAutoPageBreak(TRUE, 20);
    $pdf->AddPage();

    // Informasi Dokter
    $pdf->SetFont('helvetica', 'B', 14);
    $pdf->Cell(0, 10, 'DATA DOKTER', 0, 1, 'C');
    $pdf->Ln(5);

    // Tabel Data Dokter
    $pdf->SetFont('helvetica', '', 12);
    $tbl = '
    <table border="1" cellpadding="6" cellspacing="0">
        <tr bgcolor="#f2f2f2">
            <td width="30%"><b>ID Dokter</b></td>
            <td width="70%">' . $dokter['id_dokter'] . '</td>
        </tr>
        <tr>
            <td><b>Nama Dokter</b></td>
            <td>' . $dokter['nama_dokter'] . '</td>
        </tr>
        <tr bgcolor="#f2f2f2">
            <td><b>NIK</b></td>
            <td>' . $dokter['nik'] . '</td>
        </tr>
        <tr>
            <td><b>Spesialis</b></td>
            <td>' . $dokter['spesialis'] . '</td>
        </tr>
        <tr bgcolor="#f2f2f2">
            <td><b>Telepon</b></td>
            <td>' . $dokter['telepon'] . '</td>
        </tr>
        <tr>
            <td><b>Alamat</b></td>
            <td>' . $dokter['alamat'] . '</td>
        </tr>
    </table>';
    $pdf->writeHTML($tbl, true, false, false, false, '');

    // Tambahkan foto dokter jika ada
    if (!empty($dokter['foto']) && file_exists('uploads/' . $dokter['foto'])) {
        $pdf->Ln(10);
        $pdf->SetFont('helvetica', 'B', 12);
        $pdf->Cell(0, 10, 'Foto Dokter', 0, 1, 'C');
        $pdf->Image('uploads/' . $dokter['foto'], 75, $pdf->GetY(), 50, 50, '', '', '', false, 300, '', false, false, 1, false, false, false);
    }

    // Output PDF
    $pdf->Output('Data_Dokter_' . $dokter['id_dokter'] . '.pdf', 'D');
} else {
    echo "ID dokter tidak ditemukan.";
}
?>
