<?php
require_once('../tcpdf/tcpdf.php');
include '../koneksi.php';

// URL lengkap ke folder uploads (sesuaikan dengan server Anda)
$base_url = "http://localhost/new/dokter/uploads/";

// Ambil data dokter dari database
$query = "SELECT * FROM dokter";
$result = $koneksi->query($query);

// Kelas custom untuk header & footer
class MYPDF extends TCPDF {
    public function Header() {
        // Logo Rumah Sakit
        $image_file = '../assets/logo.png'; // Pastikan logo ada di path ini
        if (file_exists($image_file)) {
            $this->Image($image_file, 15, 10, 20); // Logo kiri atas
        }

        // Judul Rumah Sakit
        $this->SetFont('helvetica', 'B', 16);
        $this->Cell(0, 5, 'RUMAH SAKIT MEDIKA PRATAMA', 0, 1, 'C');

        // Informasi Rumah Sakit
        $this->SetFont('helvetica', '', 10);
        $this->Cell(0, 5, 'Jl. Kesehatan No. 123, Jakarta', 0, 1, 'C');
        $this->Cell(0, 5, 'Telp: (021) 555-6789 | Email: info@rssehat.com', 0, 1, 'C');

        // Judul Laporan
        $this->SetFont('helvetica', 'B', 12);
        $this->Cell(0, 8, 'DAFTAR DOKTER', 0, 1, 'C');

        // Garis pemisah
        $this->Ln(2);
        $this->Cell(190, 0, '', 'T', 1, 'C');
        $this->Ln(5);
    }

    public function Footer() {
        $this->SetY(-15);
        $this->SetFont('helvetica', 'I', 8);
        $this->Cell(0, 10, 'Halaman ' . $this->getAliasNumPage() . ' dari ' . $this->getAliasNbPages(), 0, 0, 'C');
    }
}

// Inisialisasi PDF
$pdf = new MYPDF('P', 'mm', 'A4', true, 'UTF-8', false);
$pdf->SetMargins(10, 40, 10);
$pdf->SetAutoPageBreak(TRUE, 15);
$pdf->AddPage();
$pdf->SetFont('helvetica', '', 10);

// Header Tabel
$pdf->SetFillColor(200, 200, 200); // Warna latar header
$pdf->SetFont('helvetica', 'B', 10);
$pdf->Cell(10, 10, 'No', 1, 0, 'C', true);
$pdf->Cell(25, 10, 'NIK', 1, 0, 'C', true);
$pdf->Cell(40, 10, 'Nama Dokter', 1, 0, 'C', true);
$pdf->Cell(30, 10, 'Spesialis', 1, 0, 'C', true);
$pdf->Cell(25, 10, 'Telepon', 1, 0, 'C', true);
$pdf->Cell(40, 10, 'Alamat', 1, 0, 'C', true);
$pdf->Cell(20, 10, 'Foto', 1, 1, 'C', true);

$pdf->SetFont('helvetica', '', 10);
$no = 1;

// Isi Tabel
while ($row = $result->fetch_assoc()) {
    $pdf->Cell(10, 20, $no++, 1, 0, 'C'); // No
    $pdf->Cell(25, 20, $row['nik'], 1, 0, 'L'); // NIK
    $pdf->Cell(40, 20, $row['nama_dokter'], 1, 0, 'L'); // Nama Dokter
    $pdf->Cell(30, 20, $row['spesialis'], 1, 0, 'L'); // Spesialis
    $pdf->Cell(25, 20, $row['telepon'], 1, 0, 'L'); // Telepon

    // MultiCell untuk alamat agar tetap rapi
    $x = $pdf->GetX();
    $y = $pdf->GetY();
    $pdf->MultiCell(40, 20, $row['alamat'], 1, 'L');
    $pdf->SetXY($x + 40, $y);

    // Foto Dokter
    $fotoPath = $base_url . $row['foto'];

    // Cek apakah gambar tersedia
    if (!empty($row['foto']) && @getimagesize($fotoPath)) {
        $pdf->Image($fotoPath, $pdf->GetX() + 1, $pdf->GetY() + 2, 18, 18, '', '', '', false, 300, '', false, false, 0, 'C', false, false);
    } else {
        $pdf->Cell(20, 20, 'No Img', 1, 0, 'C');
    }

    // Pindah ke baris berikutnya
    $pdf->Ln(20);
}

// Output PDF
$pdf->Output('Daftar_Dokter.pdf', 'D');
?>
