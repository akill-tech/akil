<?php
session_start();
include '../koneksi.php';

// Inisialisasi variabel cari
$cari = isset($_GET['cari']) ? $_GET['cari'] : '';

// Proses update data dokter
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_dokter'])) {
    $id_dokter = $_POST['edit_id_dokter'];
    $nama_dokter = $_POST['edit_nama_dokter'];
    $nik = $_POST['edit_nik'];
    $spesialis = $_POST['edit_spesialis'];
    $telepon = $_POST['edit_telepon'];
    $alamat = $_POST['edit_alamat'];

    $query = "UPDATE dokter SET nama_dokter='$nama_dokter', nik='$nik', spesialis='$spesialis', telepon='$telepon', alamat='$alamat' WHERE id_dokter='$id_dokter'";
    if ($koneksi->query($query)) {
        echo "<script>alert('Data dokter berhasil diperbarui!'); window.location='tampil_dokter.php';</script>";
    } else {
        echo "<script>alert('Gagal memperbarui data!');</script>";
    }
}

$query = "SELECT * FROM dokter";
if (!empty($cari)) {
    $query .= " WHERE nama_dokter LIKE '%$cari%' OR nik LIKE '%$cari%' OR spesialis LIKE '%$cari%' OR telepon LIKE '%$cari%' OR alamat LIKE '%$cari%'";
}
$result = $koneksi->query($query);

?>


<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Dokter</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body class="bg-gray-100">

<header class="bg-white shadow">
    <div class="container mx-auto px-4 py-4 flex justify-between items-center">
        <span class="text-lg font-semibold">Sistem Informasi Rumah Sakit</span>
        <nav class="flex space-x-4">
                          <a href="../index.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                <i class="fas fa-home"></i>
                    Dasboard
                </a>
            <a href="../pasien/tampil_pasien.php" class="px-4 py-2 bg-gray-600 text-white rounded"><i class="fas fa-user"></i>Data Pasien</a>
            <a href="../prj/tampil_prj.php" class="px-4 py-2 bg-gray-600 text-white rounded"><i class="fas fa-bed"></i> Pasien Rawat Jalan</a>
            <a href="../pri/tampil_pri.php" class="px-4 py-2 bg-gray-600 text-white rounded"><i class="fas fa-procedures"></i> Pasien Rawat Inap</a>
            <a href="../kamar/tampil_kamar.php" class="px-4 py-2 bg-gray-600 text-white rounded"><i class="fas fa-hospital"></i> Daftar Kamar</a>
            <a href="tampil_dokter.php" class="px-4 py-2 bg-gray-600 text-white rounded"><i class="fas fa-user-md"></i> Daftar Dokter</a>
                             <a href="../tkerja/tampil_tenaga_kerja.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                    <i class="fas fa-user-md"></i> Daftar Tenaga Kerja
                </a>
        </nav>
                <div class="flex items-center space-x-4">
            <span class="text-gray-700">Selamat Datang, <strong><?= $_SESSION['username']; ?></strong></span>
            <a href="../logout.php" class="text-red-600">Logout</a>
        </div>
    </div>
</header>
<main class="container mx-auto px-4 py-8">
    <div class="bg-white shadow rounded-lg p-6">
        <div class="text-center mb-6">
            <h1 class="text-2xl font-semibold text-red-600">Daftar Dokter</h1>
            <button onclick="openModalTambah()" class="mt-4 px-4 py-2 bg-red-600 text-white rounded">
                + Tambah Dokter
            </button>
            
            <a href="download_dokter.php" class="mt-4 px-4 py-2 bg-red-600 text-white rounded">
        <i class="fas fa-file-pdf"></i> Download PDF
    </a>
        </div>
        <form method="GET" action="tampil_dokter.php" class="flex items-center space-x-2">
        <input type="text" name="cari" value="<?= htmlspecialchars($cari); ?>" placeholder="Cari nama dokter..." class="px-4 py-2 border rounded-lg w-1/3">
        <button type="submit" class="px-4 py-2 bg-red-600 text-white rounded">Cari</button>
        <a href="tampil_dokter.php" class="px-4 py-2 bg-gray-600 text-white rounded">Reset</a>
    </form>
        <div class="overflow-x-auto mt-6">
            <table class="min-w-full bg-white border">
            <thead>
    <tr class="bg-gray-200 text-gray-600 uppercase text-sm">
        <th class="py-3 px-4 text-left">No</th>
        <th class="py-3 px-4 text-left">ID Dokter</th>
        <th class="py-3 px-4 text-left">Nama Dokter</th>
        <th class="py-3 px-4 text-left">NIK</th>
        <th class="py-3 px-4 text-left">Spesialis</th>
        <th class="py-3 px-4 text-left">Telepon</th>
        <th class="py-3 px-4 text-left">Alamat</th>
        <th class="py-3 px-4 text-left">Foto</th>
        <th class="py-3 px-4 text-left">Aksi</th>
        <th class="py-3 px-4 text-left">Download PDF</th>
    </tr>
</thead>
<tbody class="text-gray-600 text-sm">
    <?php 
    $no = 1; 
    while ($row = $result->fetch_assoc()) { ?>
        <tr class='border-b border-gray-200 hover:bg-gray-100'>
            <td class='py-3 px-4 font-bold'><?= $no++; ?></td>
            <td class='py-3 px-4 font-bold'><?= $row['id_dokter']; ?></td>
            <td class='py-3 px-4 font-bold'><?= $row['nama_dokter']; ?></td>
            <td class='py-3 px-4 font-bold'><?= $row['nik']; ?></td>
            <td class='py-3 px-4 font-bold'><?= $row['spesialis']; ?></td>
            <td class='py-3 px-4 font-bold'><?= $row['telepon']; ?></td>
            <td class='py-3 px-4 font-bold'><?= $row['alamat']; ?></td>
            <td class='py-3 px-4'>
                <img src="uploads/<?= $row['foto']; ?>" alt="Foto Dokter" class="w-10 h-10 rounded-full cursor-pointer" onclick="openImageModal('uploads/<?= $row['foto']; ?>')">
            </td>
            <td class='py-3 px-4'>
                <button onclick="openModalEdit(<?= htmlspecialchars(json_encode($row)) ?>)" class='text-blue-600'>
                    <i class='fas fa-edit'></i>
                </button>
                <a href="aksi_hapus_dokter.php?id_dokter=<?= $row['id_dokter']; ?>" class='text-red-600' onclick="return confirm('Yakin ingin menghapus data dokter ini?')">
                    <i class='fas fa-trash'></i>
                </a>
            </td>
            <td class='py-3 px-4 text-center'>
                <a href="download_pdf_dokter.php?id_dokter=<?= $row['id_dokter']; ?>" class="text-green-600">
                    <i class="fas fa-file-pdf"></i> Download
                </a>
            </td>
        </tr>
    <?php } ?>
</tbody>


            </table>
        </div>
    </div>
</main>

<!-- Modal Pratinjau Gambar -->
<div id="imageModal" class="hidden fixed inset-0 bg-gray-900 bg-opacity-50 flex justify-center items-center">
    <div class="bg-white rounded-lg p-6 shadow-lg relative">
        <button onclick="closeImageModal()" class="absolute top-2 right-2 text-gray-600 text-xl">&times;</button>
        <img id="imagePreview" class="w-64 h-auto mx-auto rounded-lg" alt="Pratinjau Foto Dokter">
    </div>
</div>
<!-- Modal Edit -->
<div id="editModal" class="hidden fixed inset-0 bg-gray-900 bg-opacity-50 flex justify-center items-center">
    <div class="bg-white rounded-lg p-6 shadow-lg relative w-96">
        <button onclick="closeModal()" class="absolute top-2 right-2 text-gray-600 text-xl">&times;</button>
        <h2 class="text-xl font-semibold text-gray-700 mb-4">Edit Data Dokter</h2>
<form action="aksi_edit_dokter.php" method="POST" enctype="multipart/form-data">
        <form action="" method="POST">
            <input type="hidden" name="edit_id_dokter" id="edit_id_dokter">

            <label class="block text-gray-700 font-semibold">Nama Dokter</label>
            <input type="text" name="edit_nama_dokter" id="edit_nama_dokter" class="w-full px-3 py-2 border rounded-lg mb-3" required>

            <label class="block text-gray-700 font-semibold">NIK</label>
            <input type="text" name="edit_nik" id="edit_nik" class="w-full px-3 py-2 border rounded-lg mb-3" required>

            <label class="block text-gray-700 font-semibold">Spesialis</label>
            <input type="text" name="edit_spesialis" id="edit_spesialis" class="w-full px-3 py-2 border rounded-lg mb-3" required>

            <label class="block text-gray-700 font-semibold">Telepon</label>
            <input type="text" name="edit_telepon" id="edit_telepon" class="w-full px-3 py-2 border rounded-lg mb-3" required>

            <label class="block text-gray-700 font-semibold">Alamat</label>
            <input type="text" name="edit_alamat" id="edit_alamat" class="w-full px-3 py-2 border rounded-lg mb-3" required>
                        <!-- Foto Lama -->
            <label class="block text-gray-700 font-semibold">Foto Lama</label>
            <img id="edit_foto_lama" class="w-20 h-20 mx-auto rounded-full mb-3" alt="Foto Lama">

            <!-- Input untuk mengganti foto -->
            <label class="block text-gray-700 font-semibold">Ganti Foto</label>
            <input type="file" name="edit_foto" id="edit_foto" class="w-full px-3 py-2 border rounded-lg mb-3" accept="image/*" onchange="previewEditImage(event)">
            
            <!-- Pratinjau Foto Baru -->
            <img id="edit_preview" class="w-20 h-20 mx-auto rounded-full mb-3 hidden" alt="Pratinjau Foto Baru">

            <button type="submit" name="update_dokter" class="w-full bg-red-500 text-white py-2 rounded-lg font-semibold">Simpan</button>
        </form>
    </div>
</div><!-- Modal Tambah Dokter -->
<div id="tambahModal" class="hidden fixed inset-0 bg-gray-900 bg-opacity-50 flex justify-center items-center">
    <div class="bg-white rounded-lg p-6 shadow-lg relative w-96">
        <button onclick="closeModalTambah()" class="absolute top-2 right-2 text-gray-600 text-xl">&times;</button>
        <h2 class="text-xl font-semibold text-gray-700 mb-4">Tambah Dokter Baru</h2>

        <form action="upload_dokter.php" method="POST" enctype="multipart/form-data">
            <label class="block text-gray-700 font-semibold">Nama Dokter</label>
            <input type="text" name="nama_dokter" class="w-full px-3 py-2 border rounded-lg mb-3" required>

            <label class="block text-gray-700 font-semibold">NIK</label>
            <input type="text" name="nik" class="w-full px-3 py-2 border rounded-lg mb-3" required>

            <label class="block text-gray-700 font-semibold">Spesialis</label>
            <input type="text" name="spesialis" class="w-full px-3 py-2 border rounded-lg mb-3" required>

            <label class="block text-gray-700 font-semibold">Telepon</label>
            <input type="text" name="telepon" class="w-full px-3 py-2 border rounded-lg mb-3" required>

            <label class="block text-gray-700 font-semibold">Alamat</label>
            <input type="text" name="alamat" class="w-full px-3 py-2 border rounded-lg mb-3" required>

            <label class="block text-gray-700 font-semibold">Foto Dokter</label>
            <input type="file" name="foto" id="foto" class="w-full px-3 py-2 border rounded-lg mb-3" accept="image/*" required onchange="previewImage(event)">
            
            <!-- Pratinjau Gambar -->
            <img id="preview" class="w-32 h-32 mx-auto rounded-full mb-3 hidden" alt="Pratinjau Foto Dokter">

            <button type="submit" class="w-full bg-red-500 text-white py-2 rounded-lg font-semibold">Simpan</button>
        </form>
    </div>
</div>

<script>
    function openImageModal(imageSrc) {
        document.getElementById("imagePreview").src = imageSrc;
        document.getElementById("imageModal").classList.remove("hidden");
    }

    function closeImageModal() {
        document.getElementById("imageModal").classList.add("hidden");
    }
        function openModalEdit(data) {
        document.getElementById("edit_id_dokter").value = data.id_dokter;
        document.getElementById("edit_nama_dokter").value = data.nama_dokter;
        document.getElementById("edit_nik").value = data.nik;
        document.getElementById("edit_spesialis").value = data.spesialis;
        document.getElementById("edit_telepon").value = data.telepon;
        document.getElementById("edit_alamat").value = data.alamat;
        document.getElementById("editModal").classList.remove("hidden");
    }

    function closeModal() {
        document.getElementById("editModal").classList.add("hidden");
    }
    function openModalTambah() {
        document.getElementById("tambahModal").classList.remove("hidden");
    }

    function closeModalTambah() {
        document.getElementById("tambahModal").classList.add("hidden");
    }
    function openModalEdit(data) {
        document.getElementById("edit_id_dokter").value = data.id_dokter;
        document.getElementById("edit_nama_dokter").value = data.nama_dokter;
        document.getElementById("edit_nik").value = data.nik;
        document.getElementById("edit_spesialis").value = data.spesialis;
        document.getElementById("edit_telepon").value = data.telepon;
        document.getElementById("edit_alamat").value = data.alamat;

        // Menampilkan foto lama
        if (data.foto) {
            document.getElementById("edit_foto_lama").src = "uploads/" + data.foto;
            document.getElementById("edit_foto_lama").classList.remove("hidden");
        } else {
            document.getElementById("edit_foto_lama").classList.add("hidden");
        }

        document.getElementById("editModal").classList.remove("hidden");
    }

    function closeModal() {
        document.getElementById("editModal").classList.add("hidden");
    }

    function previewEditImage(event) {
        const reader = new FileReader();
        reader.onload = function () {
            const preview = document.getElementById("edit_preview");
            preview.src = reader.result;
            preview.classList.remove("hidden");
        };
        reader.readAsDataURL(event.target.files[0]);
    }
</script>

</body>
</html>
