<?php
session_start();
include '../koneksi.php';

// Ambil data tenaga kerja
$query = "SELECT id_tenaga_kerja, nik, nama, jenis_kelamin, alamat, telepon, jabatan, foto FROM tenaga_kerja";
$result = $koneksi->query($query);
 if (isset($_GET['message'])): ?>
    <?php if ($_GET['message'] == 'delete_success'): ?>
    
    <?php elseif ($_GET['message'] == 'delete_failed'): ?>
        <div class="alert alert-danger">Gagal menghapus data tenaga kerja.</div>
    <?php elseif ($_GET['message'] == 'worker_not_found'): ?>
        <div class="alert alert-warning">Data tenaga kerja tidak ditemukan.</div>
    <?php elseif ($_GET['message'] == 'invalid_request'): ?>
    <?php endif; ?>
<?php endif;
// Ambil kata kunci pencarian
$kataKunci = isset($_GET['cari']) ? $_GET['cari'] : '';

// Ubah query sesuai kata kunci
$query = "SELECT id_tenaga_kerja, nik, nama, jenis_kelamin, alamat, telepon, jabatan, foto FROM tenaga_kerja";
if ($kataKunci) {
    $query .= " WHERE nama LIKE '%$kataKunci%' OR jabatan LIKE '%$kataKunci%'";
}
$result = $koneksi->query($query);

?>


<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Tenaga Kerja</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body class="bg-gray-100">
<header class="bg-white shadow">
    <div class="container mx-auto px-4 py-4 flex justify-between items-center">
        <div class="flex items-center space-x-4">
            <span class="text-lg font-semibold">Sistem Informasi Rumah Sakit</span>
            <nav class="flex space-x-4">
                              <a href="../index.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                <i class="fas fa-home"></i>
                    Dasboard
                </a>
                <a href="../pasien/tampil_pasien.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                    <i class="fas fa-user"></i>Data Pasien
                </a>
                <a href="../prj/tampil_prj.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                    <i class="fas fa-bed"></i> Pasien Rawat Jalan
                </a>
                <a href="../pri/tampil_pri.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                    <i class="fas fa-procedures"></i> Pasien Rawat Inap
                </a>
                <a href="../kamar/tampil_kamar.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                    <i class="fas fa-hospital"></i> Daftar Kamar
                </a>
                <a href="../dokter/tampil_dokter.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                    <i class="fas fa-user-md"></i> Daftar Dokter
                </a>
                                 <a href="../tkerja/tampil_tenaga_kerja.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                    <i class="fas fa-user-md"></i> Daftar Tenaga Kerja
                </a>
            </nav>
        </div>

                <div class="flex items-center space-x-4">
            <span class="text-gray-700">Selamat Datang, <strong><?= $_SESSION['username']; ?></strong></span>
            <a href="../logout.php" class="text-red-600">Logout</a>
        </div>
    </div>
</header>

<main class="container mx-auto px-4 py-8">
    <div class="bg-white shadow rounded-lg p-6">
        <div class="text-center mb-6">
            <h1 class="text-2xl font-semibold text-pink-600">Data Tenaga Kerja</h1>
            <button onclick="openModalTambah()" class="mt-4 px-4 py-2 bg-pink-600 text-white rounded">+ Tambah Tenaga Kerja</button>
        </div>
        <form method="GET" action="tampil_tenaga_kerja.php" class="flex items-center space-x-2">
        <input type="text" name="cari" value="<?= isset($_GET['cari']) ? htmlspecialchars($_GET['cari']) : ''; ?>" placeholder="Cari tenaga kerja..." class="px-4 py-2 border rounded-lg w-1/3">
        <button type="submit" class="px-4 py-2 bg-pink-600 text-white rounded">Cari</button>
        <a href="tampil_tenaga_kerja.php" class="px-4 py-2 bg-gray-600 text-white rounded">Reset</a>
    </form>

        <div class="overflow-x-auto mt-6">
            <table class="min-w-full bg-white border">
            <thead>
    <tr class="bg-gray-200 text-gray-600 uppercase text-sm leading-normal">
        <th class="py-3 px-6 text-left">No</th>
        <th class="py-3 px-6 text-left">NIK</th>
        <th class="py-3 px-6 text-left">Nama</th>
        <th class="py-3 px-6 text-left">Jenis Kelamin</th>
        <th class="py-3 px-6 text-left">Alamat</th>
        <th class="py-3 px-6 text-left">Telepon</th>
        <th class="py-3 px-6 text-left">Jabatan</th>
        <th class="py-3 px-6 text-left">Foto</th>
        <th class="py-3 px-6 text-left">Aksi</th>
    </tr>
</thead>
<tbody class="text-gray-600 text-sm font-light">
    <?php $no = 1; while ($row = $result->fetch_assoc()) { ?>
        <tr class='border-b border-gray-200 hover:bg-gray-100'>
            <td class='py-3 px-6 text-left font-bold'><?= $no++; ?></td>
            <td class='py-3 px-6 text-left font-bold'><?= $row['nik']; ?></td> <!-- Tambahkan NIK -->
            <td class='py-3 px-6 text-left font-bold'><?= $row['nama']; ?></td>
            <td class='py-3 px-6 text-left font-bold'><?= ($row['jenis_kelamin'] == "L") ? "Laki-laki" : "Perempuan"; ?></td>
            <td class='py-3 px-6 text-left font-bold'><?= $row['alamat']; ?></td>
            <td class='py-3 px-6 text-left font-bold'><?= $row['telepon']; ?></td>
            <td class='py-3 px-6 text-left font-bold'><?= $row['jabatan']; ?></td>
            <td class='py-3 px-6 text-left'>
                <img src="uploads/<?= $row['foto']; ?>" alt="Foto" class="w-10 h-10 rounded-full cursor-pointer" onclick="openImageModal('uploads/<?= $row['foto']; ?>')">
            </td>
            <td class='py-3 px-4'>
                <button onclick="openEditModal(<?= htmlspecialchars(json_encode($row)) ?>)" class='text-blue-600'>
                    <i class='fas fa-edit'></i>
                </button>
                <a href="aksi_hapus_tkerja.php?id_tenaga_kerja=<?= $row['id_tenaga_kerja']; ?>" class='text-red-600' onclick="return confirm('Yakin ingin menghapus data tenaga kerja ini?')">
                    <i class='fas fa-trash'></i>
                </a>
            </td>
        </tr>
    <?php } ?>
</tbody>


            </table>
        </div>
    </div>
</main>

<!-- Modal Pratinjau Gambar -->
<div id="imageModal" class="hidden fixed inset-0 bg-gray-900 bg-opacity-50 flex justify-center items-center">
    <div class="bg-white rounded-lg p-6 shadow-lg relative">
        <button onclick="closeImageModal()" class="absolute top-2 right-2 text-gray-600 text-xl">&times;</button>
        <img id="imagePreview" class="w-64 h-auto mx-auto rounded-lg" alt="Pratinjau Foto Dokter">
    </div>
</div>


<!-- Modal Edit Data Tenaga Kerja -->
<div id="modalEdit" class="fixed inset-0 bg-gray-900 bg-opacity-50 hidden flex justify-center items-center">
    <div class="bg-white p-6 rounded-lg shadow-lg w-1/3">
        <h2 class="text-xl font-semibold mb-4">Edit Data Tenaga Kerja</h2>
        <form id="editForm" action="aksi_edit_tkerja.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="id_tenaga_kerja" id="editId">
            <div class="mb-4">
    <label class="block text-sm font-medium">NIK</label>
    <input type="text" name="nik" id="editNIK" required class="w-full border px-3 py-2 rounded">
</div>
            <div class="mb-4">
                <label class="block text-sm font-medium">Nama</label>
                <input type="text" name="nama" id="editNama" required class="w-full border px-3 py-2 rounded">
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium">Jenis Kelamin</label>
                <select name="jenis_kelamin" id="editJenisKelamin" required class="w-full border px-3 py-2 rounded">
                    <option value="L">Laki-laki</option>
                    <option value="P">Perempuan</option>
                </select>
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium">Alamat</label>
                <textarea name="alamat" id="editAlamat" required class="w-full border px-3 py-2 rounded"></textarea>
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium">Telepon</label>
                <input type="text" name="telepon" id="editTelepon" required class="w-full border px-3 py-2 rounded">
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium">Jabatan</label>
                <input type="text" name="jabatan" id="editJabatan" required class="w-full border px-3 py-2 rounded">
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium">Foto (Opsional)</label>
                <input type="file" name="foto" id="editFoto" class="w-full border px-3 py-2 rounded">
            </div>
            <div class="flex justify-end space-x-2">
                <button type="button" onclick="closeEditModal()" class="px-4 py-2 bg-gray-400 text-white rounded">Batal</button>
                <button type="submit" class="px-4 py-2 bg-green-600 text-white rounded">Simpan</button>
            </div>
        </form>
    </div>
</div>


<!-- Modal Tambah Tenaga Kerja -->
<div id="modalTambah" class="fixed inset-0 bg-gray-900 bg-opacity-50 hidden flex justify-center items-center">
    <div class="bg-white p-6 rounded-lg shadow-lg w-1/3">
        <h2 class="text-xl font-semibold mb-4">Tambah Tenaga Kerja</h2>
        <form action="aksi_tambah_tkerja.php" method="POST" enctype="multipart/form-data">
            <div class="mb-4">
                <label class="block text-sm font-medium">NIK</label>
                <input type="text" name="nik" required class="w-full border px-3 py-2 rounded">
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium">Nama</label>
                <input type="text" name="nama" required class="w-full border px-3 py-2 rounded">
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium">Jenis Kelamin</label>
                <select name="jenis_kelamin" required class="w-full border px-3 py-2 rounded">
                    <option value="L">Laki-laki</option>
                    <option value="P">Perempuan</option>
                </select>
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium">Alamat</label>
                <textarea name="alamat" required class="w-full border px-3 py-2 rounded"></textarea>
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium">Telepon</label>
                <input type="text" name="telepon" required class="w-full border px-3 py-2 rounded">
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium">Jabatan</label>
                <input type="text" name="jabatan" required class="w-full border px-3 py-2 rounded">
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium">Foto</label>
                <input type="file" name="foto" required class="w-full border px-3 py-2 rounded">
            </div>
            <div class="flex justify-end space-x-2">
                <button type="button" onclick="closeModalTambah()" class="px-4 py-2 bg-gray-400 text-white rounded">Batal</button>
                <button type="submit" class="px-4 py-2 bg-green-600 text-white rounded">Simpan</button>
            </div>
        </form>
    </div>
</div>

<!-- Script untuk Modal -->
<script>

    // Script Modal Tambah
function openModalTambah() {
    document.getElementById('modalTambah').classList.remove('hidden');
}

function closeModalTambah() {
    document.getElementById('modalTambah').classList.add('hidden');
}


function openImageModal(imageSrc) {
        document.getElementById("imagePreview").src = imageSrc;
        document.getElementById("imageModal").classList.remove("hidden");
    }

    function closeImageModal() {
        document.getElementById("imageModal").classList.add("hidden");
    }
    function closeEditModal() {
    document.getElementById('modalEdit').classList.add('hidden');
}

// Script Modal Edit
function closeEditModal() {
    document.getElementById('modalEdit').classList.add('hidden');
}

function openEditModal(workerData) {
    // Isi data form dengan data dari tabel
    document.getElementById('editId').value = workerData.id_tenaga_kerja;
    document.getElementById('editNIK').value = workerData.nik;
    document.getElementById('editNama').value = workerData.nama;
    document.getElementById('editJenisKelamin').value = workerData.jenis_kelamin;
    document.getElementById('editAlamat').value = workerData.alamat;
    document.getElementById('editTelepon').value = workerData.telepon;
    document.getElementById('editJabatan').value = workerData.jabatan;
    
    // Tampilkan modal
    document.getElementById('modalEdit').classList.remove('hidden');
}

</script>



</body>
</html>
