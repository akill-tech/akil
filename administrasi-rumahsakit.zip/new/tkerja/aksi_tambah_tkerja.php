<?php
session_start();
include '../koneksi.php';

// Cek apakah form telah disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil data dari form
    $nik = $_POST['nik'];
    $nama = $_POST['nama'];
    $jenis_kelamin = $_POST['jenis_kelamin'];
    $alamat = $_POST['alamat'];
    $telepon = $_POST['telepon'];
    $jabatan = $_POST['jabatan'];
    $foto = $_FILES['foto'];

    // Cek apakah NIK sudah ada di database
    $cekNik = $koneksi->query("SELECT * FROM tenaga_kerja WHERE nik = '$nik'");
    if ($cekNik->num_rows > 0) {
        // Jika sudah ada, arahkan kembali dengan pesan error
        header("Location: tampil_tenaga_kerja.php?message=nik_exists");
        exit();
    }

    // Proses upload foto
    $targetDir = "uploads/";
    $fotoName = basename($foto['name']);
    $targetFilePath = $targetDir . $fotoName;
    $imageFileType = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));
    $uploadOk = 1;

    // Cek apakah file gambar atau bukan
    $check = getimagesize($foto['tmp_name']);
    if ($check !== false) {
        $uploadOk = 1;
    } else {
        $uploadOk = 0;
    }

    // Cek ukuran file (maksimal 2MB)
    if ($foto['size'] > 2000000) {
        $uploadOk = 0;
    }

    // Cek ekstensi file
    $allowedExtensions = array('jpg', 'jpeg', 'png', 'gif');
    if (!in_array($imageFileType, $allowedExtensions)) {
        $uploadOk = 0;
    }

    // Jika lolos pengecekan, upload file
    if ($uploadOk == 1) {
        if (move_uploaded_file($foto['tmp_name'], $targetFilePath)) {
            // Jika berhasil diupload, simpan data ke database
            $query = "INSERT INTO tenaga_kerja (nik, nama, jenis_kelamin, alamat, telepon, jabatan, foto) 
                      VALUES ('$nik', '$nama', '$jenis_kelamin', '$alamat', '$telepon', '$jabatan', '$fotoName')";

            if ($koneksi->query($query) === TRUE) {
                // Berhasil menambah data
                header("Location: tampil_tenaga_kerja.php?message=add_success");
                exit();
            } else {
                // Gagal menambah data, tampilkan pesan error MySQL
                echo "Error: " . $query . "<br>" . $koneksi->error;
                exit();
            }
        } else {
            // Gagal mengupload foto
            header("Location: tampil_tenaga_kerja.php?message=upload_failed");
            exit();
        }
    } else {
        // Gagal validasi file
        header("Location: tampil_tenaga_kerja.php?message=invalid_file");
        exit();
    }
} else {
    // Jika akses langsung tanpa submit form
    header("Location: tampil_tenaga_kerja.php?message=invalid_request");
    exit();
}
?>
