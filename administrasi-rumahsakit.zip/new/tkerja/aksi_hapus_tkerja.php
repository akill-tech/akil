<?php
session_start();
include '../koneksi.php';

// Periksa apakah parameter id_tenaga_kerja ada
if (isset($_GET['id_tenaga_kerja'])) {
    $id_tenaga_kerja = $_GET['id_tenaga_kerja'];

    // Cek apakah data tenaga kerja dengan ID ini ada
    $queryCek = "SELECT foto FROM tenaga_kerja WHERE id_tenaga_kerja = ?";
    $stmtCek = $koneksi->prepare($queryCek);
    $stmtCek->bind_param("i", $id_tenaga_kerja);
    $stmtCek->execute();
    $resultCek = $stmtCek->get_result();

    if ($resultCek->num_rows > 0) {
        $data = $resultCek->fetch_assoc();
        $foto = $data['foto'];

        // Hapus data dari database
        $queryHapus = "DELETE FROM tenaga_kerja WHERE id_tenaga_kerja = ?";
        $stmtHapus = $koneksi->prepare($queryHapus);
        $stmtHapus->bind_param("i", $id_tenaga_kerja);

        if ($stmtHapus->execute()) {
            // Hapus file foto jika ada
            if (!empty($foto) && file_exists("uploads/$foto")) {
                unlink("uploads/$foto");
            }
            // Redirect dengan pesan sukses
            header("Location: tampil_tenaga_kerja.php?message=delete_success");
            exit;
        } else {
            // Redirect dengan pesan gagal
            header("Location: tampil_tenaga_kerja.php?message=delete_failed");
            exit;
        }
    } else {
        // Redirect jika data tidak ditemukan
        header("Location: tampil_tenaga_kerja.php?message=worker_not_found");
        exit;
    }
} else {
    // Redirect jika request tidak valid
    header("Location: tampil_tenaga_kerja.php?message=invalid_request");
    exit;
}
?>
