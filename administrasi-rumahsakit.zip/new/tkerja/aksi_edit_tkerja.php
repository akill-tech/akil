<?php
include '../koneksi.php';

$id_tenaga_kerja = $_POST['id_tenaga_kerja'];
$nik = $_POST['nik'];
$nama = $_POST['nama'];
$jenis_kelamin = $_POST['jenis_kelamin'];
$alamat = $_POST['alamat'];
$telepon = $_POST['telepon'];
$jabatan = $_POST['jabatan'];

// Update tanpa mengganti foto
$query = "UPDATE tenaga_kerja SET 
    nik = '$nik', 
    nama = '$nama', 
    jenis_kelamin = '$jenis_kelamin', 
    alamat = '$alamat', 
    telepon = '$telepon', 
    jabatan = '$jabatan'
    WHERE id_tenaga_kerja = '$id_tenaga_kerja'";

if ($koneksi->query($query) === TRUE) {
    header("Location: tampil_tenaga_kerja.php?message=edit_success");
} else {
    header("Location: tampil_tenaga_kerja.php?message=edit_failed");
}
?>
