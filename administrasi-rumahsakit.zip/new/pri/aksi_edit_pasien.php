<?php
include '../koneksi.php';

$id_pasien = $_POST['id_pasien'];
$nik = $_POST['nik']; // NIK
$nama_pasien = $_POST['nama_pasien'];
$jenis_kelamin = $_POST['jenis_kelamin'];
$alamat = $_POST['alamat'];
$telepon = $_POST['telepon'];
$dokter = $_POST['dokter'];
$id_kamar = $_POST['id_kamar'];
$tanggal_daftar = $_POST['tanggal_daftar'];
$tanggal_keluar = !empty($_POST['tanggal_keluar']) ? $_POST['tanggal_keluar'] : NULL;
$pembayaran = $_POST['pembayaran'];
$keluhan = $_POST['keluhan']; // New field for the patient's complaint

// Prepare the query to update patient data
$query = "UPDATE pasien_rawat_inap 
            SET nik = '$nik', 
                nama_pasien = '$nama_pasien', 
                jenis_kelamin = '$jenis_kelamin', 
                alamat = '$alamat', 
                telepon = '$telepon', 
                dokter = '$dokter', 
                id_kamar = '$id_kamar', 
                tanggal_daftar = '$tanggal_daftar', 
                tanggal_keluar = NULLIF('$tanggal_keluar', ''), 
                pembayaran = '$pembayaran', 
                status_pembayaran = '$status_pembayaran', 
                keluhan = '$keluhan'  -- Adding keluhan to the update query
          WHERE id_pasien = '$id_pasien'";

// Execute the query and check if it was successful
if ($koneksi->query($query) === TRUE) {
    echo "<script>alert('Data berhasil diperbarui!'); window.location='tampil_pri.php';</script>";
} else {
    echo "Error: " . $query . "<br>" . $koneksi->error;
}

$koneksi->close();
?>
