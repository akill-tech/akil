<?php
include '../koneksi.php';

if (isset($_GET['id_pasien'])) {
    $id_pasien = $_GET['id_pasien'];

    // Query untuk menghapus pasien berdasarkan ID
    $query = "DELETE FROM pasien_rawat_inap WHERE id_pasien = ?";
    $stmt = $koneksi->prepare($query);
    $stmt->bind_param("s", $id_pasien);

    if ($stmt->execute()) {
        echo "<script>alert('Data pasien berhasil dihapus!'); window.location.href = 'tampil_pri.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus data pasien!'); window.location.href = 'tampil_pri.php';</script>";
    }

    $stmt->close();
} else {
    echo "<script>alert('ID pasien tidak ditemukan!'); window.location.href = 'tampil_pri.php';</script>";
}

$koneksi->close();
?>