<?php
include '../koneksi.php';

$id_pasien = $_POST['id_pasien'];
$nik = $_POST['nik']; // Tambahkan NIK
$nama_pasien = $_POST['nama_pasien'];
$jenis_kelamin = $_POST['jenis_kelamin'];
$alamat = $_POST['alamat'];
$telepon = $_POST['telepon'];
$dokter = $_POST['dokter'];
$id_kamar = $_POST['id_kamar'];
$tanggal_daftar = $_POST['tanggal_daftar'];
$tanggal_keluar = !empty($_POST['tanggal_keluar']) ? $_POST['tanggal_keluar'] : NULL;
$pembayaran = $_POST['pembayaran'];
$keluhan = $_POST['keluhan']; // New field for the patient's complaint

$query = "INSERT INTO pasien_rawat_inap 
            (id_pasien, nik, nama_pasien, jenis_kelamin, alamat, telepon, dokter, id_kamar, tanggal_daftar, tanggal_keluar, pembayaran, status_pembayaran, keluhan) 
          VALUES 
            ('$id_pasien', '$nik', '$nama_pasien', '$jenis_kelamin', '$alamat', '$telepon', '$dokter', '$id_kamar', '$tanggal_daftar', NULLIF('$tanggal_keluar', ''), '$pembayaran', '$status_pembayaran', '$keluhan')";

if ($koneksi->query($query) === TRUE) {
    echo "<script>alert('Data berhasil ditambahkan!'); window.location='tampil_pri.php';</script>";
} else {
    echo "Error: " . $query . "<br>" . $koneksi->error;
}

$koneksi->close();
?>
