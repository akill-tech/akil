<?php
include '../koneksi.php';

if (isset($_GET['id_pasien'])) {
    $id_pasien = $_GET['id_pasien'];
    $query = "SELECT * FROM pasien WHERE id_pasien = '$id_pasien'";
    $result = $koneksi->query($query);

    if ($result->num_rows > 0) {
        $data = $result->fetch_assoc();
        echo json_encode([
            "status" => "ada",
            "nik" => $data['nik'],
            "nama_pasien" => $data['nama_pasien'],
            "jenis_kelamin" => $data['jenis_kelamin'],
            "alamat" => $data['alamat'],
            "telepon" => $data['telepon']
        ]);
    } else {
        echo json_encode(["status" => "tidak_ada"]);
    }
}
?>
