<?php
session_start();
// Sertakan koneksi ke database
include '../koneksi.php';

// Ambil data pasien rawat inap beserta informasi kamar
$query = "SELECT pri.id_pasien, pri.nik, pri.nama_pasien, pri.jenis_kelamin, pri.alamat, pri.telepon, pri.dokter, pri.status_pembayaran, pri.pembayaran, k.nomor_kamar, pri.tanggal_daftar, pri.tanggal_keluar, pri.pembayaran, pri.keluhan
          FROM pasien_rawat_inap pri 
          LEFT JOIN kamar k ON pri.id_kamar = k.id_kamar";
$result = $koneksi->query($query);

$cari = isset($_GET['cari']) ? $koneksi->real_escape_string($_GET['cari']) : '';


if (!empty($cari)) {
    $stmt = $koneksi->prepare("SELECT pri.id_pasien, pri.nik, pri.nama_pasien, pri.jenis_kelamin, pri.alamat, pri.telepon, pri.dokter, pri.status_pembayaran, pri.pembayaran, k.nomor_kamar, pri.tanggal_daftar, pri.tanggal_keluar, pri.keluhan
          FROM pasien_rawat_inap pri 
          LEFT JOIN kamar k ON pri.id_kamar = k.id_kamar
          WHERE pri.nama_pasien LIKE ? OR pri.nik LIKE ? OR pri.alamat LIKE ? OR pri.telepon LIKE ?");
    $search = "%$cari%";
    $stmt->bind_param("ssss", $search, $search, $search, $search);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $koneksi->query($query);
}

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Pasien Rawat Inap</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body class="bg-gray-100">
    <!-- NAVIGASI -->
<header class="bg-white shadow">
    <div class="container mx-auto px-4 py-4 flex justify-between items-center">
        <div class="flex items-center space-x-4">
            <span class="text-lg font-semibold">Sistem Informasi Rumah Sakit</span>
            <nav class="flex space-x-4">
                              <a href="../index.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                <i class="fas fa-home"></i>
                    Dasboard
                </a>
                <a href="../pasien/tampil_pasien.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                    <i class="fas fa-user"></i>Data Pasien
                </a>
                <a href="../prj/tampil_prj.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                    <i class="fas fa-bed"></i> Pasien Rawat Jalan
                </a>
                <a href="../pri/tampil_pri.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                    <i class="fas fa-procedures"></i> Pasien Rawat Inap
                </a>
                <a href="../kamar/tampil_kamar.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                    <i class="fas fa-hospital"></i> Daftar Kamar
                </a>
                <a href="../dokter/tampil_dokter.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                    <i class="fas fa-user-md"></i> Daftar Dokter
                </a>
                                 <a href="../tkerja/tampil_tenaga_kerja.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                    <i class="fas fa-user-md"></i> Daftar Tenaga Kerja
                </a>
            </nav>
        </div>
        <div class="flex items-center space-x-4">
            <span class="text-gray-700">Selamat Datang, <strong><?= $_SESSION['username']; ?></strong></span>
            <a href="../logout.php" class="text-red-600">Logout</a>
        </div>
    </div>
</header>

<!-- TAMPILAN UTAMA -->
<main class="container mx-auto px-4 py-8">
    <div class="bg-white shadow rounded-lg p-6">
        <div class="text-center mb-6">
            <h1 class="text-2xl font-semibold text-yellow-600">Data Pasien Rawat Inap</h1>
            <button onclick="openModalTambah()" class="mt-4 px-4 py-2 bg-yellow-600 text-white rounded">
                + Tambah Pasien Rawat Inap
            </button>
        </div>
        <form method="GET" action="tampil_pri.php" class="flex items-center space-x-2">
        <input type="text" name="cari" value="<?= htmlspecialchars($cari); ?>" placeholder="Cari nama pasien inap..." class="px-4 py-2 border rounded-lg w-1/3">
        <button type="submit" class="px-4 py-2 bg-yellow-600 text-white rounded">Cari</button>
        <a href="tampil_pri.php" class="px-4 py-2 bg-gray-600 text-white rounded">Reset</a>
    </form>
<!-- TABEL DATA PASIEN RAWAT INAP -->
            <div class="overflow-x-auto mt-6">
                <table class="min-w-full bg-white border">
                    <thead>
                        <tr class="bg-gray-200 text-gray-600 uppercase text-sm leading-normal">
                            <th class="py-3 px-6 text-left">No</th>
                            <th class="py-3 px-6 text-left">ID Pasien</th>
                            <th class="py-3 px-6 text-left">NIK</th>
                            <th class="py-3 px-6 text-left">Nama Pasien</th>
                            <th class="py-3 px-6 text-left">Jenis Kelamin</th>
                            <th class="py-3 px-6 text-left">Alamat</th>
                            <th class="py-3 px-6 text-left">Telepon</th>
                            <th class="py-3 px-6 text-left">Keluhan</th>
                            <th class="py-3 px-6 text-left">Dokter</th>
                            <th class="py-3 px-6 text-left">Nomor Kamar</th>
                            <th class="py-3 px-6 text-left">Tanggal Daftar</th>
                            <th class="py-3 px-6 text-left">Tanggal Keluar</th>
                            <th class="py-3 px-6 text-left">Pembayaran</th>
                        <th class="py-3 px-6 text-left">Aksi</th>
                        <th class="py-3 px-6 text-left">Download PDF</th>
                    </tr>
                        </tr>
                    </thead>
<tbody class="text-gray-600 text-sm font-light">
    <?php $no = 1; while ($row = $result->fetch_assoc()) { ?>
        <tr class='border-b border-gray-200 hover:bg-gray-100'>
            <td class='py-3 px-6 text-left font-bold'><?= $no++; ?></td>
            <td class='py-3 px-6 text-left font-bold'><?= $row['id_pasien']; ?></td>
            <td class='py-3 px-6 text-left font-bold'><?= $row['nik']; ?></td>
            <td class='py-3 px-6 text-left font-bold'><?= $row['nama_pasien']; ?></td>
            <td class='py-3 px-6 text-left font-bold'><?= ($row['jenis_kelamin'] == "L") ? "Laki-laki" : "Perempuan"; ?></td>
            <td class='py-3 px-6 text-left font-bold'><?= $row['alamat']; ?></td>
            <td class='py-3 px-6 text-left font-bold'><?= $row['telepon']; ?></td>
            <td class='py-3 px-6 text-left font-bold'><?= $row['keluhan']; ?></td>
            <td class='py-3 px-6 text-left font-bold'><?= $row['dokter']; ?></td>
            <td class='py-3 px-6 text-left font-bold'><?= $row['nomor_kamar']; ?></td>
            <td class='py-3 px-6 text-left font-bold'><?= $row['tanggal_daftar']; ?></td>
            <td class='py-3 px-6 text-left font-bold'><?= $row['tanggal_keluar']; ?></td>
            <td class='py-3 px-6 text-left font-bold'>Rp <?= number_format($row['pembayaran'], 0, ',', '.'); ?></td>
            <td class='py-3 px-6 text-left font-bold'>
<button onclick='openModalEdit(<?= htmlspecialchars(json_encode($row), ENT_QUOTES, 'UTF-8') ?>)' class='text-blue-600'>
    <i class='fas fa-edit'></i>
</button>

                <a href="aksi_hapus_pasien.php?id_pasien=<?= $row['id_pasien']; ?>" class='text-red-600' onclick="return confirm('Yakin ingin menghapus?')">
                    <i class='fas fa-trash'></i>
                </a>
                <td class='py-3 px-6 text-left font-bold'>
    <a href="download_pdf_pri.php?id_pasien=<?= $row['id_pasien']; ?>" class="text-green-600">
        <i class="fas fa-file-pdf"></i> Download
    </a>
</td>

            </td>
        </tr>
    <?php } ?>
</tbody>


            </table>
        </div>
    </div>
</main>

<!-- MODAL TAMBAH PASIEN RAWAT INAP -->
<div id="modalTambah" class="fixed inset-0 bg-black bg-opacity-50 hidden flex justify-center items-center">
    <div class="bg-white p-6 rounded-lg w-3/4 max-w-4xl">
        <h2 class="text-xl font-semibold mb-4 text-yellow-600">Tambah Pasien Rawat Inap</h2>
        <form action="aksi_tambah_pri.php" method="POST">
            <div class="grid grid-cols-2 gap-4 mb-3">
                <div>
                    <label class="block">ID Pasien</label>
                    <input type="text" id="id_pasien" name="id_pasien" class="w-full p-2 border rounded" required onkeyup="cekPasien()">
                </div>
                <div>
                    <label class="block">NIK</label>
                    <input type="text" id="nik" name="nik" class="w-full p-2 border rounded bg-gray-200" readonly>
                </div>
                <div>
                    <label class="block">Nama Pasien</label>
                    <input type="text" id="nama_pasien" name="nama_pasien" class="w-full p-2 border rounded bg-gray-200" readonly>
                </div>
                <div>
                    <label class="block">Jenis Kelamin</label>
                    <input type="text" id="jenis_kelamin" name="jenis_kelamin" class="w-full p-2 border rounded bg-gray-200" readonly>
                </div>
                <div>
                    <label class="block">Alamat</label>
                    <input type="text" id="alamat" name="alamat" class="w-full p-2 border rounded bg-gray-200" readonly>
                </div>
                <div>
                    <label class="block">Telepon</label>
                    <input type="text" id="telepon" name="telepon" class="w-full p-2 border rounded bg-gray-200" readonly>
                </div>
                <div>
    <label class="block">Keluhan</label>
    <textarea name="keluhan" class="w-full p-2 border rounded" required></textarea>
</div>

                <div>
                    <label class="block">Dokter</label>
                    <select name="dokter" class="w-full p-2 border rounded" required>
                        <option value="">Pilih Dokter</option>
                        <?php
                        $query_dokter = "SELECT nama_dokter FROM dokter";
                        $result_dokter = $koneksi->query($query_dokter);
                        while ($dokter = $result_dokter->fetch_assoc()) {
                            echo "<option value='{$dokter['nama_dokter']}'>{$dokter['nama_dokter']}</option>";
                        }
                        ?>
                    </select>
                </div>
                <div>
                    <label class="block">Nomor Kamar</label>
                    <select name="id_kamar" class="w-full p-2 border rounded" required>
                        <option value="">Pilih Kamar</option>
                        <?php
                        $query_kamar = "SELECT id_kamar, nomor_kamar FROM kamar";
                        $result_kamar = $koneksi->query($query_kamar);
                        while ($kamar = $result_kamar->fetch_assoc()) {
                            echo "<option value='{$kamar['id_kamar']}'>Kamar {$kamar['nomor_kamar']}</option>";
                        }
                        ?>
                    </select>
                </div>
                <div>
                    <label class="block">Tanggal Daftar</label>
                    <input type="date" name="tanggal_daftar" class="w-full p-2 border rounded" required>
                </div>
                <div>
                    <label class="block">Tanggal Keluar</label>
                    <input type="date" name="tanggal_keluar" class="w-full p-2 border rounded">
                </div>
                <div>
                    <label class="block">Pembayaran</label>
                    <input type="number" name="pembayaran" class="w-full p-2 border rounded" required>
                </div>
                
            </div>
            <div class="flex justify-end space-x-2 mt-4">
                <button type="button" onclick="closeModalTambah()" class="px-4 py-2 bg-gray-500 text-white rounded">Batal</button>
                <button type="submit" class="px-4 py-2 bg-yellow-600 text-white rounded">Simpan</button>
            </div>
        </form>
    </div>
</div>


<!-- MODAL EDIT PASIEN RAWAT INAP -->
<div id="modalEdit" class="fixed inset-0 bg-black bg-opacity-50 hidden flex justify-center items-center">
    <div class="bg-white p-6 rounded-lg w-3/4 max-w-4xl">
        <h2 class="text-xl font-semibold mb-4 text-yellow-600">Edit Pasien Rawat Inap</h2>
        <form action="aksi_edit_pasien.php" method="POST">
            <input type="hidden" id="edit_id_pasien" name="id_pasien">
            <div class="grid grid-cols-2 gap-4 mb-3">
                <div>
                    <label class="block">NIK</label>
                    <input type="text" id="edit_nik" name="nik" class="w-full p-2 border rounded bg-gray-200" readonly>
                </div>
                <div>
                    <label class="block">Nama Pasien</label>
                    <input type="text" id="edit_nama_pasien" name="nama_pasien" class="w-full p-2 border rounded bg-gray-200" readonly>
                </div>
                <div>
                    <label class="block">Jenis Kelamin</label>
                    <input type="text" id="edit_jenis_kelamin" name="jenis_kelamin" class="w-full p-2 border rounded bg-gray-200" readonly>
                </div>
                <div>
                    <label class="block">Alamat</label>
                    <input type="text" id="edit_alamat" name="alamat" class="w-full p-2 border rounded bg-gray-200" readonly>
                </div>
                <div>
                    <label class="block">Telepon</label>
                    <input type="text" id="edit_telepon" name="telepon" class="w-full p-2 border rounded bg-gray-200" readonly>
                </div>
                <div>
    <label class="block">Keluhan</label>
    <textarea id="edit_keluhan" name="keluhan" class="w-full p-2 border rounded"></textarea>
</div>

                <div>
                    <label class="block">Dokter</label>
                    <select id="edit_dokter" name="dokter" class="w-full p-2 border rounded" required>
                        <option value="">Pilih Dokter</option>
                        <?php
                        $query_dokter = "SELECT nama_dokter FROM dokter";
                        $result_dokter = $koneksi->query($query_dokter);
                        while ($dokter = $result_dokter->fetch_assoc()) {
                            echo "<option value='{$dokter['nama_dokter']}'>{$dokter['nama_dokter']}</option>";
                        }
                        ?>
                    </select>
                </div>
                <div>
                    <label class="block">Nomor Kamar</label>
                    <select id="edit_id_kamar" name="id_kamar" class="w-full p-2 border rounded" required>
                        <option value="">Pilih Kamar</option>
                        <?php
                        $query_kamar = "SELECT id_kamar, nomor_kamar FROM kamar";
                        $result_kamar = $koneksi->query($query_kamar);
                        while ($kamar = $result_kamar->fetch_assoc()) {
                            echo "<option value='{$kamar['id_kamar']}'>Kamar {$kamar['nomor_kamar']}</option>";
                        }
                        ?>
                    </select>
                </div>
                <div>
                    <label class="block">Tanggal Daftar</label>
                    <input type="date" id="edit_tanggal_daftar" name="tanggal_daftar" class="w-full p-2 border rounded" required>
                </div>
                <div>
                    <label class="block">Tanggal Keluar</label>
                    <input type="date" id="edit_tanggal_keluar" name="tanggal_keluar" class="w-full p-2 border rounded">
                </div>
                <div>
                    <label class="block">Pembayaran</label>
                    <input type="number" id="edit_pembayaran" name="pembayaran" class="w-full p-2 border rounded" required>
                </div>
                
            </div>
            <div class="flex justify-end space-x-2 mt-4">
                <button type="button" onclick="closeModalEdit()" class="px-4 py-2 bg-gray-500 text-white rounded">Batal</button>
                <button type="submit" class="px-4 py-2 bg-yellow-600 text-white rounded">Simpan</button>
            </div>
        </form>
    </div>
</div>

    
<script>
    
  function openModalEdit(data) {
    console.log(data); // Cek apakah data benar-benar dikirim dengan lengkap

    document.getElementById("edit_id_pasien").value = data.id_pasien || "";
    document.getElementById("edit_nik").value = data.nik || "";
    document.getElementById("edit_nama_pasien").value = data.nama_pasien || "";
    document.getElementById("edit_jenis_kelamin").value = data.jenis_kelamin || "";
    document.getElementById("edit_alamat").value = data.alamat || "";
    document.getElementById("edit_telepon").value = data.telepon || "";
    document.getElementById("edit_dokter").value = data.dokter || "";
    document.getElementById("edit_id_kamar").value = data.id_kamar || "";
    document.getElementById("edit_tanggal_daftar").value = data.tanggal_daftar || "";
    document.getElementById("edit_tanggal_keluar").value = data.tanggal_keluar || "";
    document.getElementById("edit_pembayaran").value = data.pembayaran || "";

    console.log("ID Pasien di input:", document.getElementById("edit_id_pasien").value); // Cek hasilnya
    
    document.getElementById("modalEdit").classList.remove("hidden");
}
function closeModalEdit() {
    document.getElementById("modalEdit").classList.add("hidden");
}


  
  
function openModalTambah() {
    document.getElementById("modalTambah").classList.remove("hidden");
}

function closeModalTambah() {
    document.getElementById("modalTambah").classList.add("hidden");
}

function cekPasien() {
    var idPasien = document.getElementById("id_pasien").value;

    if (idPasien.length > 0) {
        var xhr = new XMLHttpRequest();
        xhr.open("GET", "cek_pasien.php?id_pasien=" + idPasien, true);
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && xhr.status == 200) {
                var response = JSON.parse(xhr.responseText);
                if (response.status === "ada") {
                    document.getElementById("nik").value = response.nik;
                    document.getElementById("nama_pasien").value = response.nama_pasien;
                    document.getElementById("jenis_kelamin").value = response.jenis_kelamin;
                    document.getElementById("alamat").value = response.alamat;
                    document.getElementById("telepon").value = response.telepon;

                    document.getElementById("nik").readOnly = true;
                    document.getElementById("nama_pasien").readOnly = true;
                    document.getElementById("jenis_kelamin").readOnly = true;
                    document.getElementById("alamat").readOnly = true;
                    document.getElementById("telepon").readOnly = true;
                } else {
                    document.getElementById("nik").value = "";
                    document.getElementById("nama_pasien").value = "";
                    document.getElementById("jenis_kelamin").value = "";
                    document.getElementById("alamat").value = "";
                    document.getElementById("telepon").value = "";

                    document.getElementById("nik").readOnly = false;
                    document.getElementById("nama_pasien").readOnly = false;
                    document.getElementById("jenis_kelamin").readOnly = false;
                    document.getElementById("alamat").readOnly = false;
                    document.getElementById("telepon").readOnly = false;
                }
            }
        };
        xhr.send();
    }
}
</script>

