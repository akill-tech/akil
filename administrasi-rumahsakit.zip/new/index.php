<?php
session_start();

// Periksa apakah pengguna sudah login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Sistem Informasi Rumah Sakit</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        html {
            scroll-behavior: smooth;
        }
        .reveal {
            opacity: 0;
            transform: translateY(20px);
            transition: all 0.6s ease-out;
        }
        .reveal.show {
            opacity: 1;
            transform: translateY(0);
        }
    </style>
</head>
<body class="bg-gradient-to-br from-blue-50 to-white min-h-screen">

<!-- Header -->
<header class="bg-white shadow-lg sticky top-0 z-50">
    <div class="container mx-auto px-6 py-4 flex justify-between items-center">
        <div class="flex items-center space-x-4">
            <img src="images/logo.png" alt="Logo Rumah Sakit" class="w-14 h-14">
            <div>
                <h1 class="text-2xl font-bold text-gray-800">RS Medika Pratama</h1>
                <p class="text-sm text-gray-500">Melayani dengan sepenuh hati</p>
            </div>
        </div>
        <div class="flex items-center space-x-4">
            <span class="text-gray-700">Selamat Datang, <strong><?= htmlspecialchars($_SESSION['username']); ?></strong></span>
            <a href="logout.php" class="px-4 py-2 bg-red-500 text-white rounded-full hover:bg-red-600 transition duration-300 shadow-lg">
                Logout
            </a>
        </div>
    </div>
</header>

<!-- Navigasi Menu -->
<section class="py-8">
    <div class="container mx-auto grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-8">
        <a href="pasien/tampil_pasien.php" class="reveal transform transition hover:scale-105">
            <div class="bg-white p-6 rounded-2xl shadow-xl hover:shadow-2xl transition duration-300">
                <i class="fas fa-user text-3xl text-blue-500 mb-4"></i>
                <h3 class="text-xl font-semibold text-gray-800">Data Pasien</h3>
                <p class="text-gray-500">Kelola informasi pasien dengan mudah.</p>
            </div>
        </a>
        <a href="prj/tampil_prj.php" class="reveal transform transition hover:scale-105">
            <div class="bg-white p-6 rounded-2xl shadow-xl hover:shadow-2xl transition duration-300">
                <i class="fas fa-bed text-3xl text-green-500 mb-4"></i>
                <h3 class="text-xl font-semibold text-gray-800">Pasien Rawat Jalan</h3>
                <p class="text-gray-500">Pantau rawat jalan dengan efisien.</p>
            </div>
        </a>
        <a href="pri/tampil_pri.php" class="reveal transform transition hover:scale-105">
            <div class="bg-white p-6 rounded-2xl shadow-xl hover:shadow-2xl transition duration-300">
                <i class="fas fa-procedures text-3xl text-yellow-500 mb-4"></i>
                <h3 class="text-xl font-semibold text-gray-800">Pasien Rawat Inap</h3>
                <p class="text-gray-500">Lacak status rawat inap secara akurat.</p>
            </div>
        </a>
        <a href="kamar/tampil_kamar.php" class="reveal transform transition hover:scale-105">
            <div class="bg-white p-6 rounded-2xl shadow-xl hover:shadow-2xl transition duration-300">
                <i class="fas fa-hospital text-3xl text-purple-500 mb-4"></i>
                <h3 class="text-xl font-semibold text-gray-800">Daftar Kamar</h3>
                <p class="text-gray-500">Manajemen kamar lebih praktis.</p>
            </div>
        </a>
        <a href="dokter/tampil_dokter.php" class="reveal transform transition hover:scale-105">
            <div class="bg-white p-6 rounded-2xl shadow-xl hover:shadow-2xl transition duration-300">
                <i class="fas fa-user-md text-3xl text-red-500 mb-4"></i>
                <h3 class="text-xl font-semibold text-gray-800">Daftar Dokter</h3>
                <p class="text-gray-500">Informasi dokter lengkap dan akurat.</p>
            </div>
        </a>
        <a href="tkerja/tampil_tenaga_kerja.php" class="reveal transform transition hover:scale-105">
            <div class="bg-white p-6 rounded-2xl shadow-xl hover:shadow-2xl transition duration-300">
                <i class="fas fa-briefcase-medical text-3xl text-pink-500 mb-4"></i>
                <h3 class="text-xl font-semibold text-gray-800">Tenaga Kerja</h3>
                <p class="text-gray-500">Kelola tenaga kerja rumah sakit.</p>
            </div>
        </a>
    </div>
</section>

<!-- JavaScript untuk Scroll Reveal -->
<script>
    const revealElements = document.querySelectorAll('.reveal');
    const revealOnScroll = () => {
        const windowHeight = window.innerHeight;
        revealElements.forEach(el => {
            const elementTop = el.getBoundingClientRect().top;
            if (elementTop < windowHeight - 50) {
                el.classList.add('show');
            }
        });
    };
    window.addEventListener('scroll', revealOnScroll);
    window.addEventListener('load', revealOnScroll);
</script>
</body>
</html>
