<?php
session_start();
include 'koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Ambil data user dari database
    $query = "SELECT * FROM users WHERE username = '$username'";
    $result = $koneksi->query($query);

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        // Verifikasi password
        if (password_verify($password, $user['password'])) {
            $_SESSION['username'] = $user['username']; // Simpan session login
            header("Location: index.php"); // Redirect ke index.php
            exit();
        } else {
            $error = "Password salah!";
        }
    } else {
        $error = "Username tidak ditemukan!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistem Informasi Rumah Sakit</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body {
            background: linear-gradient(135deg, #667eea, #764ba2);
            position: relative;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.4);
            z-index: -1;
        }

        /* Animasi masuk */
        .fade-in {
            opacity: 0;
            transform: scale(0.9);
            animation: fadeIn 0.8s forwards;
        }

        @keyframes fadeIn {
            to {
                opacity: 1;
                transform: scale(1);
            }
        }

        /* Animasi warna gradasi pada tombol */
        .gradient-bg {
            background: linear-gradient(45deg, #667eea, #764ba2, #6bcbef, #667eea);
            background-size: 300% 300%;
            animation: gradientMove 4s ease infinite;
        }

        @keyframes gradientMove {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        /* Efek hover */
        .gradient-bg:hover {
            filter: brightness(1.1);
        }

        /* Fokus pada input */
        input:focus {
            box-shadow: 0 0 10px rgba(102, 126, 234, 0.5);
            transition: box-shadow 0.3s ease;
        }
    </style>
</head>
<body>

    <div class="overlay"></div> <!-- Overlay efek transparan -->

    <div class="bg-white p-8 rounded-2xl shadow-2xl w-full max-w-md fade-in">
        <div class="text-center">
            <h2 class="text-3xl font-bold text-gray-800">Login</h2>
            <p class="text-gray-500">Silakan masuk untuk melanjutkan</p>
        </div>

        <?php if (isset($error)) { ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mt-4">
                <?= $error; ?>
            </div>
        <?php } ?>

        <form action="" method="POST" class="mt-6">
            <div class="mb-4">
                <label class="block text-gray-700 font-semibold">Username</label>
                <input type="text" name="username" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
            </div>

            <div class="mb-4">
                <label class="block text-gray-700 font-semibold">Password</label>
                <input type="password" name="password" id="password" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                <button type="button" onclick="togglePassword()" class="text-sm text-blue-500 hover:underline mt-1">
                    Lihat Password
                </button>
            </div>

            <button type="submit" name="login" class="w-full gradient-bg text-white py-2 rounded-lg font-semibold transition duration-300">
                Masuk
            </button>
        </form>
    </div>

    <script>
        function togglePassword() {
            var passwordField = document.getElementById("password");
            if (passwordField.type === "password") {
                passwordField.type = "text";
            } else {
                passwordField.type = "password";
            }
        }
    </script>

</body>
</html>
