<?php
// Sertakan koneksi ke database
include '../koneksi.php';

// Pastikan data dikirim melalui metode POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form dengan validasi
    $id_kamar     = mysqli_real_escape_string($koneksi, $_POST['id_kamar']);
    $nomor_kamar  = mysqli_real_escape_string($koneksi, $_POST['nomor_kamar']);
    $tipe_kamar   = mysqli_real_escape_string($koneksi, $_POST['tipe_kamar']);
    $kapasitas    = mysqli_real_escape_string($koneksi, $_POST['kapasitas']);
    $tersedia     = mysqli_real_escape_string($koneksi, $_POST['tersedia']);
    $harga_per_malam = mysqli_real_escape_string($koneksi, $_POST['harga_per_malam']);

    // Pastikan kapasitas dan harga per malam adalah angka
    if (!is_numeric($kapasitas) || !is_numeric($harga_per_malam)) {
        echo "<script>
                alert('Kapasitas dan Harga per Malam harus berupa angka!');
                window.history.back();
              </script>";
        exit;
    }

    // Pastikan field "tersedia" hanya berisi "Ya" atau "Tidak"
    if ($tersedia !== "Ya" && $tersedia !== "Tidak") {
        echo "<script>
                alert('Status ketersediaan tidak valid!');
                window.history.back();
              </script>";
        exit;
    }

    // Query untuk memperbarui data kamar
    $query = "UPDATE kamar SET 
                nomor_kamar = '$nomor_kamar',
                tipe_kamar = '$tipe_kamar',
                kapasitas = '$kapasitas',
                tersedia = '$tersedia',
                harga_per_malam = '$harga_per_malam'
              WHERE id_kamar = '$id_kamar'";

    // Eksekusi query
    if ($koneksi->query($query) === TRUE) {
        echo "<script>
                alert('Data kamar berhasil diperbarui!');
                window.location.href = 'tampil_kamar.php';
              </script>";
    } else {
        echo "<script>
                alert('Gagal memperbarui data kamar: " . addslashes($koneksi->error) . "');
                window.history.back();
              </script>";
    }
} else {
    // Jika user mencoba mengakses file ini secara langsung
    echo "<script>
            alert('Akses tidak diizinkan!');
            window.location.href = 'tampil_kamar.php';
          </script>";
}

// Tutup koneksi database
$koneksi->close();
?>
<!-- MODAL TAMBAH DATA -->
<div id="modalTambah" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden">
    <div class="bg-white p-6 rounded-lg shadow-lg w-96">
        <!-- HEADER -->
        <div class="bg-purple-600 text-white px-4 py-2 rounded-t-lg">
            <h2 class="text-lg font-semibold">Tambah Kamar</h2>
        </div>

        <!-- FORM -->
        <form action="aksi_tambah_kamar.php" method="POST" class="p-4">
            <div class="mb-3">
                <label class="block text-sm font-medium text-gray-700">Nomor Kamar</label>
                <input type="text" name="nomor_kamar" required class="w-full p-2 border rounded focus:ring focus:ring-purple-300">
            </div>

            <div class="mb-3">
                <label class="block text-sm font-medium text-gray-700">Tipe Kamar</label>
                <input type="text" name="tipe_kamar" required class="w-full p-2 border rounded focus:ring focus:ring-purple-300">
            </div>

            <div class="mb-3">
                <label class="block text-sm font-medium text-gray-700">Kapasitas</label>
                <input type="number" name="kapasitas" required class="w-full p-2 border rounded focus:ring focus:ring-purple-300">
            </div>

            <div class="mb-3">
                <label class="block text-sm font-medium text-gray-700">Tersedia</label>
                <select name="tersedia" required class="w-full p-2 border rounded focus:ring focus:ring-purple-300">
                    <option value="Ya">Ya</option>
                    <option value="Tidak">Tidak</option>
                </select>
            </div>

            <div class="mb-3">
                <label class="block text-sm font-medium text-gray-700">Harga per Malam</label>
                <input type="text" name="harga_per_malam" required class="w-full p-2 border rounded focus:ring focus:ring-purple-300">
            </div>

            <!-- BUTTONS -->
            <div class="flex justify-end space-x-2 mt-4">
                <button type="button" onclick="closeModalTambah()" class="px-4 py-2 bg-gray-400 text-white rounded hover:bg-gray-500">Batal</button>
                <button type="submit" class="px-4 py-2 bg-purple-600 text-white rounded hover:bg-purple-700">Simpan</button>
            </div>
        </form>
    </div>
</div>
