<?php
session_start();
// Sertakan koneksi ke database
include '../koneksi.php';

// Ambil data kamar
$query = "SELECT * FROM kamar";
$result = $koneksi->query($query);

// Proses Pencarian
$search = '';
if (isset($_GET['search'])) {
    $search = $_GET['search'];
    $query = "SELECT * FROM kamar WHERE nomor_kamar LIKE '%$search%' OR tipe_kamar LIKE '%$search%'";
} else {
    $query = "SELECT * FROM kamar";
}
$result = $koneksi->query($query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Kamar</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body class="bg-gray-100">
    <!-- NAVIGASI -->
<header class="bg-white shadow">
    <div class="container mx-auto px-4 py-4 flex justify-between items-center">
        <div class="flex items-center space-x-4">
            <span class="text-lg font-semibold">Sistem Informasi Rumah Sakit</span>
            <nav class="flex space-x-4">
                              <a href="../index.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                <i class="fas fa-home"></i>
                    Dasboard
                </a>
                <a href="../pasien/tampil_pasien.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                    <i class="fas fa-user"></i>Data Pasien
                </a>
                <a href="../prj/tampil_prj.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                    <i class="fas fa-bed"></i> Pasien Rawat Jalan
                </a>
                <a href="../pri/tampil_pri.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                    <i class="fas fa-procedures"></i> Pasien Rawat Inap
                </a>
                <a href="tampil_kamar.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                    <i class="fas fa-hospital"></i> Daftar Kamar
                </a>
                <a href="../dokter/tampil_dokter.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                    <i class="fas fa-user-md"></i> Daftar Dokter
                </a>
                                 <a href="../tkerja/tampil_tenaga_kerja.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                    <i class="fas fa-user-md"></i> Daftar Tenaga Kerja
                </a>
            </nav>
        </div>
        <div class="flex items-center space-x-4">
            <span class="text-gray-700">Selamat Datang, <strong><?= $_SESSION['username']; ?></strong></span>
            <a href="../logout.php" class="text-red-600">Logout</a>
        </div>
    </div>
</header>

<!-- TAMPILAN UTAMA -->
<main class="container mx-auto px-4 py-8">
    <div class="bg-white shadow rounded-lg p-6">
        <div class="text-center mb-6">
            <h1 class="text-2xl font-semibold text-purple-600">Daftar Kamar</h1>
            <button onclick="openModalTambah()" class="mt-4 px-4 py-2 bg-purple-600 text-white rounded">
                + Tambah Kamar
            </button>
            <!-- FORM CARI -->
            <form method="GET" action="tampil_kamar.php" class="flex items-center space-x-2">
        <input type="text" name="search" value="<?= htmlspecialchars($search); ?>" placeholder="Cari ruangan..." class="px-4 py-2 border rounded-lg w-1/3">
        <button type="submit" class="px-4 py-2 bg-purple-600 text-white rounded">Cari</button>
        <a href="tampil_kamar.php" class="px-4 py-2 bg-gray-600 text-white rounded">Reset</a>
    </form>

        </div>
        <!-- MODAL TAMBAH DATA -->
<div id="modalTambah" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden">
    <div class="bg-white p-6 rounded shadow-lg w-96">
        <h2 class="text-lg font-semibold mb-4">Tambah Kamar</h2>
        <form action="aksi_tambah_kamar.php" method="POST">
            <input type="text" name="nomor_kamar" placeholder="Nomor Kamar" required class="w-full p-2 border rounded mb-2 focus:ring focus:ring-purple-300">
            <input type="text" name="tipe_kamar" placeholder="Tipe Kamar" required class="w-full p-2 border rounded mb-2 focus:ring focus:ring-purple-300">
            <input type="number" name="kapasitas" placeholder="Kapasitas" required class="w-full p-2 border rounded mb-2 focus:ring focus:ring-purple-300">
            <select name="tersedia" required class="w-full p-2 border rounded mb-2 focus:ring focus:ring-purple-300">
                <option value="Ya">Ya</option>
                <option value="Tidak">Tidak</option>
            </select>
            <input type="text" name="harga_per_malam" placeholder="Harga per Malam" required class="w-full p-2 border rounded mb-2 focus:ring focus:ring-purple-300">
            <div class="flex justify-end space-x-2 mt-4">
                <button type="button" onclick="closeModalTambah()" class="px-4 py-2 bg-gray-400 text-white rounded hover:bg-gray-500">Batal</button>
                <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Simpan</button>
            </div>
        </form>
    </div>
</div>



        <!-- TABEL DATA KAMAR -->
        <div class="overflow-x-auto">
            <table class="min-w-full bg-white border">
                <thead>
                    <tr class="bg-gray-200 text-gray-600 uppercase text-sm leading-normal">
                        <th class="py-3 px-6 text-left">id kamar</th>
                        <th class="py-3 px-6 text-left">Nomor Kamar</th>
                        <th class="py-3 px-6 text-left">Tipe Kamar</th>
                        <th class="py-3 px-6 text-left">Kapasitas</th>
                        <th class="py-3 px-6 text-left">Tersedia</th>
                        <th class="py-3 px-6 text-left">Harga per Malam</th>
                        <th class="py-3 px-6 text-left">Aksi</th>
                    </tr>
                </thead>
<tbody class="text-gray-600 text-sm font-light">
    <?php $no = 1; while ($row = $result->fetch_assoc()) { ?>
        <tr class='border-b border-gray-200 hover:bg-gray-100'>
            <td class='py-3 px-6 text-left font-bold'><?= $no++; ?></td>
            <td class='py-3 px-6 text-left font-bold'><?= $row['nomor_kamar']; ?></td>
            <td class='py-3 px-6 text-left font-bold'><?= $row['tipe_kamar']; ?></td>
            <td class='py-3 px-6 text-left font-bold'><?= $row['kapasitas']; ?> Orang</td>
            <td class='py-3 px-6 text-left font-bold'>
                <span class="px-2 py-1 rounded 
                    <?= ($row['tersedia'] == 'Ya') ? 'bg-green-500 text-white' : 'bg-red-500 text-white' ?>">
                    <?= $row['tersedia']; ?>
                </span>
            </td>
            <td class='py-3 px-6 text-left font-bold'>Rp <?= number_format($row['harga_per_malam'], 2, ',', '.'); ?></td>
            <td class='py-3 px-6 text-left'>
                <button onclick='openModalEdit(<?= json_encode($row, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>)' class='text-blue-600'>
                    <i class='fas fa-edit'></i>
                </button>
                <a href="aksi_hapus_kamar.php?id_kamar=<?= $row['id_kamar']; ?>" class='text-red-600' onclick="return confirm('Yakin ingin menghapus?')">
                    <i class='fas fa-trash'></i>
                </a>
            </td>
        </tr>
    <?php } ?>
</tbody>

            </table>
        </div>
    </div>
</main>

<!-- MODAL EDIT DATA -->
<div id="modalEdit" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden">
    <div class="bg-white p-6 rounded shadow-lg w-96">
        <h2 class="text-lg font-semibold mb-4">Edit Kamar</h2>
        <form id="formEdit" action="aksi_edit_kamar.php" method="POST">
            <input type="hidden" id="edit_id_kamar" name="id_kamar">
            <input type="text" id="edit_nomor_kamar" name="nomor_kamar" required class="w-full p-2 border rounded mb-2">
            <input type="text" id="edit_tipe_kamar" name="tipe_kamar" required class="w-full p-2 border rounded mb-2">
            <input type="number" id="edit_kapasitas" name="kapasitas" required class="w-full p-2 border rounded mb-2">
            <select id="edit_tersedia" name="tersedia" required class="w-full p-2 border rounded mb-2">
                <option value="Ya">Ya</option>
                <option value="Tidak">Tidak</option>
            </select>
            <input type="text" id="edit_harga_per_malam" name="harga_per_malam" required class="w-full p-2 border rounded mb-2">
            <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Simpan</button>
            <button type="button" onclick="closeModalEdit()" class="ml-2 px-4 py-2 bg-gray-400 text-white rounded">Batal</button>
        </form>
    </div>
</div>

<script>
    function openModalTambah() {
        document.getElementById("modalTambah").classList.remove("hidden");
    }

    function closeModalTambah() {
        document.getElementById("modalTambah").classList.add("hidden");
    }

    function openModalEdit(data) {
        document.getElementById("edit_id_kamar").value = data.id_kamar;
        document.getElementById("edit_nomor_kamar").value = data.nomor_kamar;
        document.getElementById("edit_tipe_kamar").value = data.tipe_kamar;
        document.getElementById("edit_kapasitas").value = data.kapasitas;
        document.getElementById("edit_tersedia").value = data.tersedia;
        document.getElementById("edit_harga_per_malam").value = data.harga_per_malam;
        document.getElementById("modalEdit").classList.remove("hidden");
    }

    function closeModalEdit() {
        document.getElementById("modalEdit").classList.add("hidden");
    }
</script>
</body>
</html>
