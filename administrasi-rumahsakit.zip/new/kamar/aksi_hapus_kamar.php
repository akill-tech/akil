<?php
// Sertakan koneksi ke database
include '../koneksi.php';

// Periksa apakah parameter id_kamar ada di URL
if (isset($_GET['id_kamar'])) {
    $id_kamar = $_GET['id_kamar'];

    // Query untuk menghapus kamar berdasarkan ID
    $query = "DELETE FROM kamar WHERE id_kamar = '$id_kamar'";

    // Eksekusi query
    if ($koneksi->query($query) === TRUE) {
        echo "<script>
                alert('Data kamar berhasil dihapus!');
                window.location.href = 'tampil_kamar.php';
              </script>";
    } else {
        echo "<script>
                alert('Gagal menghapus data kamar: " . $koneksi->error . "');
                window.history.back();
              </script>";
    }

    // Tutup koneksi
    $koneksi->close();
} else {
    // Jika tidak ada ID kamar yang dikirim
    echo "<script>
            alert('ID kamar tidak ditemukan!');
            window.location.href = 'tampil_kamar.php';
          </script>";
}
?>
