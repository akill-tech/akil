<?php
// Sertakan koneksi ke database
include '../koneksi.php';

// Periksa apakah form telah dikirim
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form
    $nomor_kamar = $_POST['nomor_kamar'];
    $tipe_kamar = $_POST['tipe_kamar'];
    $kapasitas = $_POST['kapasitas'];
    $tersedia = $_POST['tersedia'];
    
    // Hilangkan titik atau koma agar dapat disimpan sebagai angka
    $harga_per_malam = str_replace(['.', ','], '', $_POST['harga_per_malam']);
    $harga_per_malam = floatval($harga_per_malam);

    // Query untuk menambahkan kamar baru ke database
    $query = "INSERT INTO kamar (nomor_kamar, tipe_kamar, kapasitas, tersedia, harga_per_malam) 
              VALUES ('$nomor_kamar', '$tipe_kamar', '$kapasitas', '$tersedia', '$harga_per_malam')";

    // Eksekusi query
    if ($koneksi->query($query) === TRUE) {
        echo "<script>
                alert('Data kamar berhasil ditambahkan!');
                window.location.href = 'tampil_kamar.php';
              </script>";
    } else {
        echo "<script>
                alert('Gagal menambahkan data kamar: " . $koneksi->error . "');
                window.history.back();
              </script>";
    }

    // Tutup koneksi
    $koneksi->close();
} else {
    // Jika file diakses langsung tanpa melalui form
    echo "<script>
            alert('Akses tidak valid!');
            window.location.href = 'tampil_kamar.php';
          </script>";
}
?>
