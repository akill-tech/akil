<?php
session_start();
include 'koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['register'])) {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Cek apakah username sudah ada
    $check_query = "SELECT * FROM users WHERE username = '$username'";
    $check_result = $koneksi->query($check_query);

    if ($check_result->num_rows > 0) {
        $error = "Username sudah digunakan!";
    } else {
        // Simpan ke database
        $query = "INSERT INTO users (username, password) VALUES ('$username', '$password')";
        if ($koneksi->query($query)) {
            $success = "Registrasi berhasil! Silakan login.";
        } else {
            $error = "Registrasi gagal!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrasi - Sistem Informasi Rumah Sakit</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body {
            background: linear-gradient(135deg, #667eea, #764ba2);
            position: relative;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.4);
            z-index: -1;
        }

        /* Animasi masuk */
        .fade-in {
            opacity: 0;
            transform: scale(0.9);
            animation: fadeIn 0.8s forwards;
        }

        @keyframes fadeIn {
            to {
                opacity: 1;
                transform: scale(1);
            }
        }

        /* Animasi warna gradasi pada tombol */
        .gradient-bg {
            background: linear-gradient(45deg, #667eea, #764ba2, #6bcbef, #667eea);
            background-size: 300% 300%;
            animation: gradientMove 4s ease infinite;
        }

        @keyframes gradientMove {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        /* Efek hover */
        .gradient-bg:hover {
            filter: brightness(1.1);
        }

        /* Fokus pada input */
        input:focus {
            box-shadow: 0 0 10px rgba(102, 126, 234, 0.5);
            transition: box-shadow 0.3s ease;
        }
    </style>
</head>
<body>

    <div class="overlay"></div> <!-- Overlay efek transparan -->

    <div class="bg-white p-8 rounded-2xl shadow-2xl w-full max-w-md fade-in">
        <div class="text-center">
            <h2 class="text-3xl font-bold text-gray-800">Registrasi</h2>
            <p class="text-gray-500">Buat akun baru</p>
        </div>

        <?php if (isset($error)) { ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mt-4">
                <?= $error; ?>
            </div>
        <?php } ?>

        <?php if (isset($success)) { ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mt-4">
                <?= $success; ?>
            </div>
        <?php } ?>

        <form action="" method="POST" class="mt-6">
            <div class="mb-4">
                <label class="block text-gray-700 font-semibold">Username</label>
                <input type="text" name="username" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
            </div>

            <div class="mb-4">
                <label class="block text-gray-700 font-semibold">Password</label>
                <input type="password" name="password" id="password" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                <button type="button" onclick="togglePassword()" class="text-sm text-blue-500 hover:underline mt-1">
                    Lihat Password
                </button>
            </div>

            <button type="submit" name="register" class="w-full gradient-bg text-white py-2 rounded-lg font-semibold transition duration-300">
                Daftar
            </button>
        </form>
        <p class="mt-4 text-center text-gray-600">Sudah punya akun? <a href="login.php" class="text-blue-500 hover:underline">Login</a></p>
    </div>

    <script>
        function togglePassword() {
            var passwordField = document.getElementById("password");
            passwordField.type = passwordField.type === "password" ? "text" : "password";
        }
    </script>

</body>
</html>
