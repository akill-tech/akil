<?php
// Sertakan koneksi ke database
include '../koneksi.php';

// Periksa apakah ada parameter id_pasien yang dikirim melalui URL
if (isset($_GET['id_pasien'])) {
    $id_pasien = $_GET['id_pasien'];

    // Query untuk menghapus pasien berdasarkan id_pasien
    $query = "DELETE FROM pasien_rawat_jalan WHERE id_pasien = '$id_pasien'";

    if ($koneksi->query($query) === TRUE) {
        echo "<script>
                alert('Data pasien rawat jalan berhasil dihapus!');
                window.location.href = 'tampil_prj.php';
              </script>";
    } else {
        echo "<script>
                alert('Gagal menghapus data: " . addslashes($koneksi->error) . "');
                window.history.back();
              </script>";
    }
} else {
    echo "<script>
            alert('ID pasien tidak ditemukan!');
            window.history.back();
          </script>";
}

// Tutup koneksi database
$koneksi->close();
?>
