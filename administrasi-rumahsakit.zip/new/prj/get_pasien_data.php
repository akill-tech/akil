<?php
include '../koneksi.php';

if(isset($_GET['id_pasien'])) {
    $id_pasien = $_GET['id_pasien'];
    $query = "SELECT nik, nama_pasien, jenis_kelamin, alamat, telepon FROM pasien WHERE id_pasien = ?";
    $stmt = $koneksi->prepare($query);
    $stmt->bind_param("i", $id_pasien);
    $stmt->execute();
    $result = $stmt->get_result();
    $data = $result->fetch_assoc();
    
    echo json_encode($data);
}
?>
