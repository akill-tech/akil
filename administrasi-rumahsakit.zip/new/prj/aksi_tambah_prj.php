<?php
include '../koneksi.php';

// Periksa apakah form telah disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil dan sanitasi data dari form
    $nama_pasien = mysqli_real_escape_string($koneksi, $_POST['nama_pasien']);
    $jenis_kelamin = mysqli_real_escape_string($koneksi, $_POST['jenis_kelamin']);
    $alamat = mysqli_real_escape_string($koneksi, $_POST['alamat']);
    $telepon = mysqli_real_escape_string($koneksi, $_POST['telepon']);
    $tanggal_kunjungan = mysqli_real_escape_string($koneksi, $_POST['tanggal_kunjungan']);
    $keluhan = mysqli_real_escape_string($koneksi, $_POST['keluhan']);
    $nik = mysqli_real_escape_string($koneksi, $_POST['nik']);
    $pembayaran = mysqli_real_escape_string($koneksi, $_POST['pembayaran']);

    // Pastikan id_dokter tidak kosong, jika kosong set NULL
    $id_dokter = !empty($_POST['id_dokter']) ? $_POST['id_dokter'] : "NULL";

    // Query untuk menambahkan data pasien rawat jalan
    $query = "INSERT INTO pasien_rawat_jalan (nama_pasien, jenis_kelamin, alamat, telepon, tanggal_kunjungan, keluhan, nik, pembayaran, id_dokter) 
              VALUES ('$nama_pasien', '$jenis_kelamin', '$alamat', '$telepon', '$tanggal_kunjungan', '$keluhan', '$nik', '$pembayaran', $id_dokter)";

    // Eksekusi query
    if ($koneksi->query($query) === TRUE) {
        echo "<script>alert('Data pasien berhasil ditambahkan!'); window.location='tampil_prj.php';</script>";
    } else {
        echo "<script>alert('Gagal menambahkan data! Error: " . $koneksi->error . "'); window.location='tampil_prj.php';</script>";
    }
}
?>
