<?php
session_start();
include '../koneksi.php';

// Ambil data pasien rawat jalan
$query = "SELECT id_pasien, nik, nama_pasien, jenis_kelamin, alamat, telepon, id_dokter, tanggal_kunjungan, keluhan, pembayaran FROM pasien_rawat_jalan";
$result = $koneksi->query($query);

// Ambil data dokter untuk dropdown
$queryDokter = "SELECT id_dokter, nama_dokter FROM dokter";
$resultDokter = $koneksi->query($queryDokter);

$cari = isset($_GET['cari']) ? $koneksi->real_escape_string($_GET['cari']) : '';


if (!empty($cari)) {
    $stmt = $koneksi->prepare("SELECT id_pasien, nik, nama_pasien, jenis_kelamin, alamat, telepon, id_dokter, tanggal_kunjungan, keluhan, pembayaran 
        FROM pasien_rawat_jalan 
        WHERE nama_pasien LIKE ? OR nik LIKE ? OR alamat LIKE ? OR telepon LIKE ?");
    $search = "%$cari%";
    $stmt->bind_param("ssss", $search, $search, $search, $search);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $koneksi->query($query);
}

?>


<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Pasien Rawat Jalan</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body class="bg-gray-100">

<header class="bg-white shadow">
    <div class="container mx-auto px-4 py-4 flex justify-between items-center">
        <div class="flex items-center space-x-4">
            <span class="text-lg font-semibold">Sistem Informasi Rumah Sakit</span>
            <nav class="flex space-x-4">
                              <a href="../index.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                <i class="fas fa-home"></i>
                    Dasboard
                </a>
                <a href="../pasien/tampil_pasien.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                    <i class="fas fa-user"></i>Data Pasien
                </a>
                <a href="../prj/tampil_prj.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                    <i class="fas fa-bed"></i> Pasien Rawat Jalan
                </a>
                <a href="../pri/tampil_pri.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                    <i class="fas fa-procedures"></i> Pasien Rawat Inap
                </a>
                <a href="../kamar/tampil_kamar.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                    <i class="fas fa-hospital"></i> Daftar Kamar
                </a>
                <a href="../dokter/tampil_dokter.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                    <i class="fas fa-user-md"></i> Daftar Dokter
                </a>
                                 <a href="../tkerja/tampil_tenaga_kerja.php" class="px-4 py-2 bg-gray-600 text-white rounded">
                    <i class="fas fa-user-md"></i> Daftar Tenaga Kerja
                </a>
            </nav>
        </div>
        <div class="flex items-center space-x-4">
            <span class="text-gray-700">Selamat Datang, <strong><?= $_SESSION['username']; ?></strong></span>
            <a href="../logout.php" class="text-red-600">Logout</a>
        </div>
    </div>
</header>

<main class="container mx-auto px-4 py-8">
    <div class="bg-white shadow rounded-lg p-6">
        <div class="text-center mb-6">
            <h1 class="text-2xl font-semibold text-blue-600">Data Pasien Rawat Jalan</h1>
            <button onclick="openModalTambah()" class="mt-4 px-4 py-2 bg-blue-600 text-white rounded">
                + Tambah Pasien
            </button>
        </div>
        <form method="GET" action="tampil_prj.php" class="flex items-center space-x-2">
        <input type="text" name="cari" value="<?= htmlspecialchars($cari); ?>" placeholder="Cari nama pasien jalan..." class="px-4 py-2 border rounded-lg w-1/3">
        <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded">Cari</button>
        <a href="tampil_prj.php" class="px-4 py-2 bg-gray-600 text-white rounded">Reset</a>
    </form>

        <div class="overflow-x-auto mt-6">
            <table class="min-w-full bg-white border">
                        
    <tr class="bg-gray-200 text-gray-600 uppercase text-sm leading-normal">
        <th class="py-3 px-6 text-left">No</th>
        <th class="py-3 px-6 text-left">ID Pasien</th> <!-- Tambahkan kolom ID Pasien -->
        <th class="py-3 px-6 text-left">NIK</th> <!-- Kolom NIK -->
        <th class="py-3 px-6 text-left">Nama Pasien</th>
        <th class="py-3 px-6 text-left">Jenis Kelamin</th>
        <th class="py-3 px-6 text-left">Alamat</th>
        <th class="py-3 px-6 text-left">Telepon</th>
        <th class="py-3 px-6 text-left">ID Dokter</th>
        <th class="py-3 px-6 text-left">Tanggal Kunjungan</th>
        <th class="py-3 px-6 text-left">Keluhan</th>
        <th class="py-3 px-6 text-left">Pembayaran</th>
        <th class="py-3 px-6 text-left">Aksi</th>
        <th class="py-3 px-6 text-left">Download PDF</th>
    </tr>
</thead>
<tbody class="text-gray-600 text-sm font-light">
    <?php $no = 1; while ($row = $result->fetch_assoc()) { ?>
        <tr class='border-b border-gray-200 hover:bg-gray-100'>
            <td class='py-3 px-6 text-left font-bold'><?= $no++; ?></td>
            <td class='py-3 px-6 text-left font-bold'><?= $row['id_pasien']; ?></td>
            <td class='py-3 px-6 text-left font-bold'><?= $row['nik']; ?></td>
            <td class='py-3 px-6 text-left font-bold'><?= $row['nama_pasien']; ?></td>
            <td class='py-3 px-6 text-left font-bold'><?= ($row['jenis_kelamin'] == "L") ? "Laki-laki" : "Perempuan"; ?></td>
            <td class='py-3 px-6 text-left font-bold'><?= $row['alamat']; ?></td>
            <td class='py-3 px-6 text-left font-bold'><?= $row['telepon']; ?></td>
            <td class='py-3 px-6 text-left font-bold'><?= $row['id_dokter']; ?></td>
            <td class='py-3 px-6 text-left font-bold'><?= $row['tanggal_kunjungan']; ?></td>
            <td class='py-3 px-6 text-left font-bold'><?= $row['keluhan']; ?></td>
            <td class='py-3 px-6 text-left font-bold'>Rp <?= number_format($row['pembayaran'], 0, ',', '.'); ?></td>
            <td class='py-3 px-6 text-left font-bold'>
                <button onclick="openModalEdit(<?= htmlspecialchars(json_encode($row)) ?>)" class='text-blue-600'><i class='fas fa-edit'></i></button>
                <a href="aksi_hapus_prj.php?id_pasien=<?= $row['id_pasien']; ?>" class='text-red-600' onclick="return confirm('Yakin ingin menghapus?')">
                    <i class='fas fa-trash'></i>
                </a>
            </td>
            <td class='py-3 px-6 text-left font-bold'>
    <a href="download_pdf_prj.php?id_pasien=<?= $row['id_pasien']; ?>" class='text-green-600'>
        <i class='fas fa-file-pdf'></i> Download PDF
    </a>
</td>
        </tr>
    <?php } ?>
</tbody>


            </table>
        </div>
    </div>
</main>


<!-- MODAL TAMBAH PASIEN RAWAT JALAN -->
<div id="modalTambah" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden">
    <div class="bg-white p-8 rounded-lg shadow-lg w-2/4">
        <h2 class="text-2xl font-semibold mb-4 text-center text-blue-600">Tambah Pasien Rawat Jalan</h2>
        <form action="aksi_tambah_prj.php" method="POST" class="space-y-4">
            <div class="grid grid-cols-2 gap-4">
                <div class="flex flex-col">
                    <label for="id_pasien" class="text-gray-700 mb-1">ID Pasien</label>
                    <input type="number" name="id_pasien" id="id_pasien" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-600" required onblur="autoFillPasienData()">
                </div>
                <div class="flex flex-col">
                    <label for="nik" class="text-gray-700 mb-1">NIK</label>
                    <input type="text" id="nik" name="nik" class="w-full p-2 border rounded bg-gray-100" readonly>
                </div>
                <div class="flex flex-col">
                    <label for="nama_pasien" class="text-gray-700 mb-1">Nama Pasien</label>
                    <input type="text" id="nama_pasien" name="nama_pasien" class="w-full p-2 border rounded bg-gray-100" readonly>
                </div>
                <div class="flex flex-col">
                    <label for="jenis_kelamin" class="text-gray-700 mb-1">Jenis Kelamin</label>
                    <select id="jenis_kelamin" name="jenis_kelamin" class="w-full p-2 border rounded bg-gray-100" disabled>
                        <option value="L">Laki-laki</option>
                        <option value="P">Perempuan</option>
                    </select>
                </div>
                <div class="flex flex-col">
                    <label for="alamat" class="text-gray-700 mb-1">Alamat</label>
                    <input type="text" id="alamat" name="alamat" class="w-full p-2 border rounded bg-gray-100" readonly>
                </div>
                <div class="flex flex-col">
                    <label for="telepon" class="text-gray-700 mb-1">Telepon</label>
                    <input type="text" id="telepon" name="telepon" class="w-full p-2 border rounded bg-gray-100" readonly>
                </div>
                <div class="flex flex-col">
                    <label for="id_dokter" class="text-gray-700 mb-1">Dokter</label>
                    <select name="id_dokter" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-600" required>
                        <option value="">Pilih Dokter</option>
                        <?php while ($dokter = $resultDokter->fetch_assoc()) { ?>
                            <option value="<?= $dokter['id_dokter']; ?>"><?= $dokter['nama_dokter']; ?></option>
                        <?php } ?>
                    </select>
                </div>
                <div class="flex flex-col">
                    <label for="tanggal_kunjungan" class="text-gray-700 mb-1">Tanggal Kunjungan</label>
                    <input type="date" name="tanggal_kunjungan" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-600" required>
                </div>
                <div class="flex flex-col">
                    <label for="keluhan" class="text-gray-700 mb-1">Keluhan</label>
                    <textarea name="keluhan" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-600"></textarea>
                </div>
                <div class="flex flex-col">
                    <label for="pembayaran" class="text-gray-700 mb-1">Pembayaran</label>
                    <input type="number" name="pembayaran" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-600" required>
                </div>
            </div>
            <div class="flex justify-end space-x-2 mt-4">
                <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Simpan</button>
                <button type="button" onclick="closeModalTambah()" class="px-4 py-2 bg-gray-400 text-white rounded">Batal</button>
            </div>
        </form>
    </div>
</div>



<script>

function autoFillPasienData() {
    var idPasien = document.getElementById('id_pasien').value;

    if(idPasien != '') {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', 'get_pasien_data.php?id_pasien=' + idPasien, true);
        xhr.onreadystatechange = function() {
            if(xhr.readyState == 4 && xhr.status == 200) {
                var data = JSON.parse(xhr.responseText);
                
                if (data) {
                    // Auto-fill data pada field yang di-set readonly
                    document.getElementById('nik').value = data.nik;
                    document.getElementById('nama_pasien').value = data.nama_pasien;
                    document.getElementById('jenis_kelamin').value = data.jenis_kelamin;
                    document.getElementById('alamat').value = data.alamat;
                    document.getElementById('telepon').value = data.telepon;
                } else {
                    alert('Data pasien tidak ditemukan!');
                }
            }
        }
        xhr.send();
    }
}




    function openModalTambah() {
        document.getElementById("modalTambah").classList.remove("hidden");
    }
    function closeModalTambah() {
        document.getElementById("modalTambah").classList.add("hidden");
    }
</script>
<script>
   function openModalEdit(data) {
    document.getElementById("edit_id_pasien").value = data.id_pasien;
    document.getElementById("edit_nik").value = data.nik;
    document.getElementById("edit_nama_pasien").value = data.nama_pasien;
    document.getElementById("edit_jenis_kelamin").value = data.jenis_kelamin;
    document.getElementById("edit_alamat").value = data.alamat;
    document.getElementById("edit_telepon").value = data.telepon;
    document.getElementById("edit_id_dokter").value = data.id_dokter;
    document.getElementById("edit_tanggal_kunjungan").value = data.tanggal_kunjungan;
    document.getElementById("edit_keluhan").value = data.keluhan;
    document.getElementById("edit_pembayaran").value = data.pembayaran;
    
    document.getElementById("modalEdit").classList.remove("hidden");
}

function closeModalEdit() {
    document.getElementById("modalEdit").classList.add("hidden");
}
</script>

<!-- MODAL EDIT PASIEN RAWAT JALAN -->
<div id="modalEdit" class="fixed inset-0 bg-black bg-opacity-50 hidden flex justify-center items-center">
    <div class="bg-white p-6 rounded-lg w-2/4">
        <h2 class="text-2xl font-semibold mb-4 text-center text-yellow-600">Edit Pasien Rawat Jalan</h2>
        <form action="aksi_edit_prj.php" method="POST">
            <input type="hidden" id="edit_id_pasien" name="id_pasien">
            <div class="grid grid-cols-2 gap-4">
                <div class="flex flex-col">
                    <label for="edit_nik" class="text-gray-700 mb-1">NIK</label>
                    <input type="text" id="edit_nik" name="nik" class="w-full p-2 border rounded bg-gray-100" readonly>
                </div>
                <div class="flex flex-col">
                    <label for="edit_nama_pasien" class="text-gray-700 mb-1">Nama Pasien</label>
                    <input type="text" id="edit_nama_pasien" name="nama_pasien" class="w-full p-2 border rounded bg-gray-100" readonly>
                </div>
                <div class="flex flex-col">
                    <label for="edit_jenis_kelamin" class="text-gray-700 mb-1">Jenis Kelamin</label>
                    <select id="edit_jenis_kelamin" name="jenis_kelamin" class="w-full p-2 border rounded bg-gray-100" disabled>
                        <option value="L">Laki-laki</option>
                        <option value="P">Perempuan</option>
                    </select>
                </div>
                <div class="flex flex-col">
                    <label for="edit_alamat" class="text-gray-700 mb-1">Alamat</label>
                    <textarea id="edit_alamat" name="alamat" class="w-full p-2 border rounded bg-gray-100" readonly></textarea>
                </div>
                <div class="flex flex-col">
                    <label for="edit_telepon" class="text-gray-700 mb-1">Telepon</label>
                    <input type="text" id="edit_telepon" name="telepon" class="w-full p-2 border rounded bg-gray-100" readonly>
                </div>
                <div class="flex flex-col">
                    <label for="edit_id_dokter" class="text-gray-700 mb-1">Dokter</label>
                    <input type="number" id="edit_id_dokter" name="id_dokter" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-yellow-600" required>
                </div>
                <div class="flex flex-col">
                    <label for="edit_tanggal_kunjungan" class="text-gray-700 mb-1">Tanggal Kunjungan</label>
                    <input type="date" id="edit_tanggal_kunjungan" name="tanggal_kunjungan" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-yellow-600" required>
                </div>
                <div class="flex flex-col">
                    <label for="edit_keluhan" class="text-gray-700 mb-1">Keluhan</label>
                    <textarea id="edit_keluhan" name="keluhan" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-yellow-600"></textarea>
                </div>
                <div class="flex flex-col">
                    <label for="edit_pembayaran" class="text-gray-700 mb-1">Pembayaran</label>
                    <input type="number" id="edit_pembayaran" name="pembayaran" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-yellow-600" required>
                </div>
            </div>
            <div class="flex justify-end space-x-2 mt-4">
                <button type="button" onclick="closeModalEdit()" class="px-4 py-2 bg-gray-500 text-white rounded">Batal</button>
                <button type="submit" class="px-4 py-2 bg-yellow-600 text-white rounded">Simpan</button>
            </div>
        </form>
    </div>
</div>




</body>
</html>
