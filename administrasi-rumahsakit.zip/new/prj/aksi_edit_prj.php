<?php
include '../koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_pasien = $_POST['id_pasien'];
    $nama_pasien = $_POST['nama_pasien'];
    $jenis_kelamin = $_POST['jenis_kelamin'];
    $alamat = $_POST['alamat'];
    $telepon = $_POST['telepon'];
    $id_dokter = $_POST['id_dokter'];  // Perbaiki dari 'dokter' ke 'id_dokter'
    $tanggal_kunjungan = $_POST['tanggal_kunjungan'];
    $pembayaran = $_POST['pembayaran'];
    $keluhan = $_POST['keluhan'];

    // Query untuk update data pasien
    $query = "UPDATE pasien_rawat_jalan SET 
              nama_pasien = '$nama_pasien',
              jenis_kelamin = '$jenis_kelamin',
              alamat = '$alamat',
              telepon = '$telepon',
              id_dokter = '$id_dokter',
              tanggal_kunjungan = '$tanggal_kunjungan',
              pembayaran = '$pembayaran', 
              keluhan = '$keluhan'
              WHERE id_pasien = '$id_pasien'";

    if ($koneksi->query($query) === TRUE) {
        echo "<script>alert('Data berhasil diperbarui!'); window.location='tampil_prj.php';</script>";
    } else {
        echo "<script>alert('Gagal memperbarui data!'); window.location='tampil_prj.php';</script>";
    }
}

$koneksi->close();
?>
