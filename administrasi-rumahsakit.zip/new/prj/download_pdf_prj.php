<?php
// Sertakan file TCPDF dan koneksi database
require_once('../tcpdf/tcpdf.php');
include '../koneksi.php';

// Cek apakah ID pasien ada
$id_pasien = $_GET['id_pasien'] ?? '';

if (empty($id_pasien)) {
    die("ID pasien tidak ditemukan.");
}

// Query dengan JOIN untuk mengambil data lengkap
$query = "
    SELECT prj.*, d.nama_dokter
    FROM pasien_rawat_jalan prj
    LEFT JOIN dokter d ON prj.id_dokter = d.id_dokter
    WHERE prj.id_pasien = ?
";

$stmt = $koneksi->prepare($query);
$stmt->bind_param("i", $id_pasien);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if (!$row) {
    die("Data pasien tidak ditemukan.");
}

// Buat objek TCPDF
$pdf = new TCPDF('P', 'mm', 'A4', true, 'UTF-8', false);
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Sistem Rumah Sakit');
$pdf->SetTitle('Invoice Pasien Rawat Jalan');

// Tambah halaman baru
$pdf->AddPage();

// Tambahkan Logo & Informasi Rumah Sakit
$pdf->Image('../images/logo.png', 10, 10, 30, 30);
$pdf->SetFont('Helvetica', 'B', 16);
$pdf->SetXY(50, 10);
$pdf->Cell(0, 10, 'RUMAH SAKIT MEDIKA PRATAMA', 0, 1, 'L');
$pdf->SetFont('Helvetica', '', 10);
$pdf->SetXY(50, 18);
$pdf->Cell(0, 10, 'Jl. Sehat No. 123, Kota Medika, Indonesia', 0, 1, 'L');
$pdf->SetXY(50, 25);
$pdf->Cell(0, 10, 'Email: info@medikapratama.com | Website: www.rumahsakit.com', 0, 1, 'L');

// Garis pemisah
$pdf->SetLineWidth(0.5);
$pdf->Line(10, 35, 200, 35);
$pdf->Ln(10);

// Judul
$pdf->SetFont('Helvetica', 'B', 14);
$pdf->Cell(0, 10, 'INVOICE PASIEN RAWAT JALAN', 0, 1, 'C');
$pdf->Ln(5);

// Informasi Pasien
$pdf->SetFont('Helvetica', '', 10);
$pdf->SetFillColor(255, 255, 255); // Background putih
$pdf->Cell(40, 7, 'ID Pasien', 1, 0, 'L', true);
$pdf->Cell(0, 7, $row['id_pasien'], 1, 1, 'L', false);
$pdf->Cell(40, 7, 'NIK', 1, 0, 'L', true);
$pdf->Cell(0, 7, $row['nik'], 1, 1, 'L', false);
$pdf->Cell(40, 7, 'Nama Pasien', 1, 0, 'L', true);
$pdf->Cell(0, 7, $row['nama_pasien'], 1, 1, 'L', false);
$pdf->Cell(40, 7, 'Jenis Kelamin', 1, 0, 'L', true);
$pdf->Cell(0, 7, ($row['jenis_kelamin'] == 'L' ? 'Laki-laki' : 'Perempuan'), 1, 1, 'L', false);
$pdf->Cell(40, 7, 'Alamat', 1, 0, 'L', true);
$pdf->Cell(0, 7, $row['alamat'], 1, 1, 'L', false);
$pdf->Ln(5);

// Informasi Rawat Jalan
$pdf->SetFont('Helvetica', 'B', 12);
$pdf->Cell(0, 10, 'RINCIAN RAWAT JALAN', 0, 1, 'L');
$pdf->SetFont('Helvetica', '', 10);
$pdf->SetFillColor(255, 255, 255); // Background putih
$pdf->Cell(40, 7, 'Dokter', 1, 0, 'L', true);
$pdf->Cell(0, 7, $row['nama_dokter'] ?? 'Tidak Diketahui', 1, 1, 'L', false);
$pdf->Cell(40, 7, 'Keluhan', 1, 0, 'L', true);
$pdf->Cell(0, 7, $row['keluhan'], 1, 1, 'L', false);
$pdf->Cell(40, 7, 'Tanggal Kunjungan', 1, 0, 'L', true);
$pdf->Cell(0, 7, $row['tanggal_kunjungan'], 1, 1, 'L', false);
$pdf->Ln(5);

// Informasi Biaya
$pdf->SetFont('Helvetica', 'B', 12);
$pdf->Cell(0, 10, 'DETAIL PEMBAYARAN', 0, 1, 'L');
$pdf->SetFont('Helvetica', '', 10);
$pdf->SetFillColor(255, 255, 255); // Background putih
$pdf->Cell(40, 7, 'Biaya Rawat', 1, 0, 'L', true);
$pdf->Cell(0, 7, 'Rp ' . number_format($row['pembayaran'], 0, ',', '.'), 1, 1, 'L', false);
$pdf->Ln(10);

// Tanda Tangan
$pdf->SetFont('Helvetica', '', 10);
$pdf->Cell(0, 10, 'Kota Sehat, ' . date('d-m-Y'), 0, 1, 'R');
$pdf->Cell(0, 10, 'Dokter Penanggung Jawab,', 0, 1, 'R');
$pdf->Ln(15);
$pdf->SetFont('Helvetica', 'B', 10);
$pdf->Cell(0, 10, '________________________', 0, 1, 'R');
$pdf->Cell(0, 10, $row['nama_dokter'] ?? 'Tidak Diketahui', 0, 1, 'R');

// Output PDF
$pdf->Output('invoice_pasien_' . $id_pasien . '.pdf', 'I');
?>
