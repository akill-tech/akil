<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Inisialisasi mode gelap dari cookie jika ada
$darkMode = isset($_COOKIE['darkMode']) && $_COOKIE['darkMode'] === 'true';
?>

<!DOCTYPE html>
<html lang="id" class="<?= $darkMode ? 'dark' : '' ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Sistem Informasi Rumah Sakit</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        dark: {
                            100: '#1E293B',
                            200: '#0F172A',
                            300: '#0B1120',
                        }
                    }
                }
            }
        }
    </script>
    <style>
        html {
            scroll-behavior: smooth;
        }
        .reveal {
            opacity: 0;
            transform: translateY(20px);
            transition: all 0.6s ease-out;
        }
        .reveal.show {
            opacity: 1;
            transform: translateY(0);
        }
        .card-hover-effect {
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        .card-hover-effect::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            transition: 0.5s;
        }
        .card-hover-effect:hover::before {
            left: 100%;
        }
        .pulse-effect {
            animation: pulse 2s infinite;
        }
        @keyframes pulse {
            0% { box-shadow: 0 0 0 0 rgba(99, 102, 241, 0.4); }
            70% { box-shadow: 0 0 0 10px rgba(99, 102, 241, 0); }
            100% { box-shadow: 0 0 0 0 rgba(99, 102, 241, 0); }
        }
        .floating {
            animation: floating 3s ease-in-out infinite;
        }
        @keyframes floating {
            0% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
            100% { transform: translateY(0px); }
        }
        /* Dark mode specific styles */
        .dark .card-hover-effect::before {
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.05), transparent);
        }
    </style>
</head>
<body class="bg-gradient-to-br from-blue-50 to-white min-h-screen dark:bg-gradient-to-br dark:from-dark-200 dark:to-dark-300">

<!-- Header dengan toggle dark mode -->
<header class="bg-white shadow-lg sticky top-0 z-50 dark:bg-dark-100">
    <div class="container mx-auto px-6 py-4 flex justify-between items-center">
        <div class="flex items-center space-x-4">
            <img src="images/logo.png" alt="Logo Rumah Sakit" class="w-14 h-14 floating">
            <div>
                <h1 class="text-2xl font-bold text-gray-800 dark:text-white">RS Medika Pratama</h1>
                <p class="text-sm text-gray-500 dark:text-gray-300">Melayani dengan sepenuh hati</p>
            </div>
        </div>
                    <button id="darkModeToggle" class="p-2 rounded-full focus:outline-none">
                <i class="fas <?= $darkMode ? 'fa-sun text-yellow-400' : 'fa-moon text-gray-600' ?>"></i>
            </button>
        <div class="flex items-center space-x-4">
            <span class="text-gray-700 dark:text-gray-300">Selamat Datang, <strong class="text-blue-600 dark:text-blue-400"><?= htmlspecialchars($_SESSION['username']); ?></strong></span>
            
            <a href="logout.php" class="px-4 py-2 bg-red-500 text-white rounded-full hover:bg-red-600 transition duration-300 shadow-lg pulse-effect dark:bg-red-600 dark:hover:bg-red-700">
                Logout <i class="fas fa-sign-out-alt ml-1"></i>
            </a>
        </div>
    </div>
</header>

<!-- Navigasi Menu -->
<section class="py-8">
    <div class="container mx-auto grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-8">
        <!-- Card Data Pasien -->
        <a href="pasien/tampil_pasien.php" class="reveal transform transition hover:scale-105">
            <div class="bg-white p-6 rounded-2xl shadow-xl hover:shadow-2xl transition duration-300 card-hover-effect dark:bg-dark-100 dark:hover:shadow-lg dark:hover:shadow-blue-500/20">
                <div class="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4 mx-auto dark:bg-blue-900/30">
                    <i class="fas fa-user text-xl text-blue-500 dark:text-blue-400"></i>
                </div>
                <h3 class="text-xl font-semibold text-gray-800 text-center dark:text-white">Data Pasien</h3>
                <p class="text-gray-500 text-center mt-2 dark:text-gray-300">Kelola informasi pasien dengan mudah.</p>
                <div class="mt-4 text-center">
                    <span class="inline-block px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm dark:bg-blue-900/30 dark:text-blue-300">Akses Cepat</span>
                </div>
            </div>
        </a>
        
        <!-- Card Rawat Jalan -->
        <a href="prj/tampil_prj.php" class="reveal transform transition hover:scale-105">
            <div class="bg-white p-6 rounded-2xl shadow-xl hover:shadow-2xl transition duration-300 card-hover-effect dark:bg-dark-100 dark:hover:shadow-lg dark:hover:shadow-green-500/20">
                <div class="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mb-4 mx-auto dark:bg-green-900/30">
                    <i class="fas fa-bed text-xl text-green-500 dark:text-green-400"></i>
                </div>
                <h3 class="text-xl font-semibold text-gray-800 text-center dark:text-white">Pasien Rawat Jalan</h3>
                <p class="text-gray-500 text-center mt-2 dark:text-gray-300">Pantau rawat jalan dengan efisien.</p>
                <div class="mt-4 text-center">
                    <span class="inline-block px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm dark:bg-green-900/30 dark:text-green-300">Update Realtime</span>
                </div>
            </div>
        </a>
        
        <!-- Card Rawat Inap -->
        <a href="pri/tampil_pri.php" class="reveal transform transition hover:scale-105">
            <div class="bg-white p-6 rounded-2xl shadow-xl hover:shadow-2xl transition duration-300 card-hover-effect dark:bg-dark-100 dark:hover:shadow-lg dark:hover:shadow-yellow-500/20">
                <div class="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center mb-4 mx-auto dark:bg-yellow-900/30">
                    <i class="fas fa-procedures text-xl text-yellow-500 dark:text-yellow-400"></i>
                </div>
                <h3 class="text-xl font-semibold text-gray-800 text-center dark:text-white">Pasien Rawat Inap</h3>
                <p class="text-gray-500 text-center mt-2 dark:text-gray-300">Lacak status rawat inap secara akurat.</p>
                <div class="mt-4 text-center">
                    <span class="inline-block px-3 py-1 bg-yellow-100 text-yellow-800 rounded-full text-sm dark:bg-yellow-900/30 dark:text-yellow-300">Prioritas</span>
                </div>
            </div>
        </a>
        
        <!-- Card Daftar Kamar -->
        <a href="kamar/tampil_kamar.php" class="reveal transform transition hover:scale-105">
            <div class="bg-white p-6 rounded-2xl shadow-xl hover:shadow-2xl transition duration-300 card-hover-effect dark:bg-dark-100 dark:hover:shadow-lg dark:hover:shadow-purple-500/20">
                <div class="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mb-4 mx-auto dark:bg-purple-900/30">
                    <i class="fas fa-hospital text-xl text-purple-500 dark:text-purple-400"></i>
                </div>
                <h3 class="text-xl font-semibold text-gray-800 text-center dark:text-white">Daftar Kamar</h3>
                <p class="text-gray-500 text-center mt-2 dark:text-gray-300">Manajemen kamar lebih praktis.</p>
                <div class="mt-4 text-center">
                    <span class="inline-block px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm dark:bg-purple-900/30 dark:text-purple-300">Ketersediaan</span>
                </div>
            </div>
        </a>

        <!-- Card Daftar Dokter -->
        <a href="dokter/tampil_dokter.php" class="reveal transform transition hover:scale-105">
            <div class="bg-white p-6 rounded-2xl shadow-xl hover:shadow-2xl transition duration-300 card-hover-effect dark:bg-dark-100 dark:hover:shadow-lg dark:hover:shadow-red-500/20">
                <div class="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mb-4 mx-auto dark:bg-red-900/30">
                    <i class="fas fa-user-md text-xl text-red-500 dark:text-red-400"></i>
                </div>
                <h3 class="text-xl font-semibold text-gray-800 text-center dark:text-white">Daftar Dokter</h3>
                <p class="text-gray-500 text-center mt-2 dark:text-gray-300">Informasi dokter lengkap dan akurat.</p>
                <div class="mt-4 text-center">
                    <span class="inline-block px-3 py-1 bg-red-100 text-red-800 rounded-full text-sm dark:bg-red-900/30 dark:text-red-300">Spesialis</span>
                </div>
            </div>
        </a>

        <!-- Card Tenaga Kerja -->
        <a href="tkerja/tampil_tenaga_kerja.php" class="reveal transform transition hover:scale-105">
            <div class="bg-white p-6 rounded-2xl shadow-xl hover:shadow-2xl transition duration-300 card-hover-effect dark:bg-dark-100 dark:hover:shadow-lg dark:hover:shadow-pink-500/20">
                <div class="w-12 h-12 bg-pink-100 rounded-full flex items-center justify-center mb-4 mx-auto dark:bg-pink-900/30">
                    <i class="fas fa-briefcase-medical text-xl text-pink-500 dark:text-pink-400"></i>
                </div>
                <h3 class="text-xl font-semibold text-gray-800 text-center dark:text-white">Tenaga Kerja</h3>
                <p class="text-gray-500 text-center mt-2 dark:text-gray-300">Kelola tenaga kerja rumah sakit.</p>
                <div class="mt-4 text-center">
                    <span class="inline-block px-3 py-1 bg-pink-100 text-pink-800 rounded-full text-sm dark:bg-pink-900/30 dark:text-pink-300">Staff</span>
                </div>
            </div>
        </a>
    </div>
</section>

<!-- Floating Action Button -->
<div class="fixed bottom-8 right-8 z-50">
    <button class="w-14 h-14 bg-blue-500 text-white rounded-full shadow-lg hover:bg-blue-600 transition duration-300 flex items-center justify-center text-xl pulse-effect dark:bg-blue-600 dark:hover:bg-blue-700" 
            onclick="window.scrollTo({top: 0, behavior: 'smooth'})">
        <i class="fas fa-arrow-up"></i>
    </button>
</div>

<!-- Notifikasi Toast -->
<div id="toast" class="fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg transform translate-x-full transition-transform duration-300 hidden dark:bg-green-600">
    <div class="flex items-center">
        <i class="fas fa-check-circle mr-2"></i>
        <span>Selamat datang kembali, <?= htmlspecialchars($_SESSION['username']); ?>!</span>
    </div>
</div>

<script>
    // Dark Mode Toggle
    const darkModeToggle = document.getElementById('darkModeToggle');
    const html = document.documentElement;
    
    darkModeToggle.addEventListener('click', () => {
        html.classList.toggle('dark');
        const isDarkMode = html.classList.contains('dark');
        
        // Simpan preferensi di cookie (expires dalam 30 hari)
        document.cookie = `darkMode=${isDarkMode}; path=/; max-age=${60 * 60 * 24 * 30}`;
        
        // Update icon
        const icon = darkModeToggle.querySelector('i');
        if (isDarkMode) {
            icon.classList.replace('fa-moon', 'fa-sun');
            icon.classList.replace('text-gray-600', 'text-yellow-400');
        } else {
            icon.classList.replace('fa-sun', 'fa-moon');
            icon.classList.replace('text-yellow-400', 'text-gray-600');
        }
    });

    // Scroll Reveal
    const revealElements = document.querySelectorAll('.reveal');
    const revealOnScroll = () => {
        const windowHeight = window.innerHeight;
        revealElements.forEach(el => {
            const elementTop = el.getBoundingClientRect().top;
            if (elementTop < windowHeight - 50) {
                el.classList.add('show');
            }
        });
    };
    
    // Tampilkan toast notifikasi
    document.addEventListener('DOMContentLoaded', () => {
        revealOnScroll();
        
        const toast = document.getElementById('toast');
        setTimeout(() => {
            toast.classList.remove('hidden');
            toast.classList.remove('translate-x-full');
            toast.classList.add('translate-x-0');
        }, 1000);
        
        setTimeout(() => {
            toast.classList.add('translate-x-full');
            setTimeout(() => toast.classList.add('hidden'), 300);
        }, 5000);
    });
    
    window.addEventListener('scroll', revealOnScroll);
</script>
</body>
</html>