<?php
// Menetapkan parameter koneksi
$host = 'localhost'; // atau IP address server database jika tidak menggunakan localhost
$username = 'root';  // Gantilah dengan username MySQL Anda
$password = '';      // Gantilah dengan password MySQL Anda jika ada
$database = 'rumah_sakit'; // Nama database yang telah dibuat

// Membuat koneksi ke database
$koneksi = new mysqli($host, $username, $password, $database);

// Cek koneksi
if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
} else {
    // Jika koneksi berhasil, Anda bisa mencetak atau melakukan proses lebih lanjut
    echo "";
}
?>
